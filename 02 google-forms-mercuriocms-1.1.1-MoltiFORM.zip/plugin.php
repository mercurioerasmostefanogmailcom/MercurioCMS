<?php
/**
 * Google Forms per MercurioCMS 1.1.0.
 * Basato sulla versione 1.0.2: mantiene integralmente la navigazione e il
 * caricamento del pannello originali; aggiunge soltanto i moduli multipli.
 */

if (!function_exists('cms_google_forms_normalize_url')) {
    function cms_google_forms_normalize_url(string $input): string
    {
        $input = trim($input);
        if ($input === '' || strlen($input) > 2048) return '';
        $parts = parse_url($input);
        if (!is_array($parts)) return '';
        if (strtolower((string)($parts['scheme'] ?? '')) !== 'https'
            || strtolower((string)($parts['host'] ?? '')) !== 'docs.google.com'
            || isset($parts['user']) || isset($parts['pass'])
            || isset($parts['port']) || isset($parts['fragment'])) return '';
        $path = (string)($parts['path'] ?? '');
        if (!preg_match('~^/forms/d/(?:e/)?[A-Za-z0-9_-]+/viewform/?$~D', $path)) return '';
        return 'https://docs.google.com' . rtrim($path, '/') . '?embedded=true';
    }
}

if (!function_exists('cms_google_forms_items')) {
    /** Legge i moduli multipli e migra le vecchie impostazioni singole. */
    function cms_google_forms_items(): array
    {
        $raw = function_exists('cms_setting') ? cms_setting('google_forms_items', '') : '';
        if (is_string($raw) && $raw !== '') {
            $decoded = json_decode($raw, true);
            if (is_array($decoded)) {
                $items = [];
                foreach ($decoded as $item) {
                    if (!is_array($item)) continue;
                    $id = strtolower(trim((string)($item['id'] ?? '')));
                    $url = cms_google_forms_normalize_url((string)($item['url'] ?? ''));
                    $height = (int)($item['height'] ?? 1200);
                    if (!preg_match('/^[a-z0-9_-]{1,40}$/', $id) || $url === '') continue;
                    if ($height < 400 || $height > 6000) $height = 1200;
                    $items[$id] = ['id'=>$id,'name'=>(string)($item['name'] ?? $id),'url'=>$url,'height'=>$height];
                }
                if ($items) return $items;
            }
        }
        $legacyUrl = cms_google_forms_normalize_url((string)(function_exists('cms_setting') ? cms_setting('google_forms_embed_url', '') : ''));
        if ($legacyUrl === '') return [];
        $height = (int)(function_exists('cms_setting') ? cms_setting('google_forms_height', '1200') : 1200);
        if ($height < 400 || $height > 6000) $height = 1200;
        return ['adesione'=>['id'=>'adesione','name'=>'Adesione','url'=>$legacyUrl,'height'=>$height]];
    }
}

if (!function_exists('cms_google_forms_iframe')) {
    function cms_google_forms_iframe(array $item): string
    {
        $url = cms_google_forms_normalize_url((string)($item['url'] ?? ''));
        if ($url === '') return '';
        $height = (int)($item['height'] ?? 1200);
        if ($height < 400 || $height > 6000) $height = 1200;
        $title = htmlspecialchars((string)($item['name'] ?? 'Modulo Google Forms'), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        $safeUrl = htmlspecialchars($url, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        return '<iframe src="' . $safeUrl . '" title="' . $title . '" width="100%" height="' . $height . '" style="display:block;width:100%;max-width:100%;height:' . $height . 'px;border:0;background:#fff" loading="lazy" referrerpolicy="strict-origin-when-cross-origin" allow="fullscreen"></iframe>';
    }
}

if (!function_exists('cms_google_forms_render_buffer')) {
    function cms_google_forms_render_buffer(string $html): string
    {
        $script = str_replace('\\', '/', (string)($_SERVER['SCRIPT_NAME'] ?? ''));
        if (basename($script) !== 'index.php' || stripos($html, '<html') === false) return $html;

        $hasMarker = strpos($html, '[[MERCURIO_GOOGLE_FORMS') !== false;
        $hasLegacyMarker = stripos($html, 'mercurio-google-form') !== false;
        if (!$hasMarker && !$hasLegacyMarker) return $html;

        $items = cms_google_forms_items();
        $first = $items ? reset($items) : null;

        // Segnaposto con ID: ogni segnaposto richiama il modulo corrispondente.
        $html = preg_replace_callback('~\[\[MERCURIO_GOOGLE_FORMS:([a-zA-Z0-9_-]{1,40})\]\]~', function ($m) use ($items) {
            $id = strtolower($m[1]);
            return isset($items[$id]) ? cms_google_forms_iframe($items[$id]) : '';
        }, $html) ?? $html;

        // Segnaposto precedente e span legacy: visualizzano il primo modulo.
        $legacyIframe = $first ? cms_google_forms_iframe($first) : '';
        $html = str_replace('[[MERCURIO_GOOGLE_FORMS]]', $legacyIframe, $html);
        return preg_replace('~<span\b(?=[^>]*\bid=["\']mercurio-google-form["\'])[^>]*>\s*</span>~i', $legacyIframe, $html) ?? $html;
    }
}

// Registrazione e percorsi originali della versione 1.0.2: non modificati.
if (function_exists('cms_register_admin_menu')) {
    cms_register_admin_menu('google-forms', 'Google Forms', '../plugins/google-forms/admin.php');
}
$cmsGoogleFormsScript = str_replace('\\', '/', (string)($_SERVER['SCRIPT_NAME'] ?? ''));
if (basename($cmsGoogleFormsScript) === 'index.php' && !headers_sent()) {
    ob_start('cms_google_forms_render_buffer');
}
