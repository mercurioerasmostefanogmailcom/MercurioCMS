<?php
require_once __DIR__ . '/../../app/bootstrap.php';
require_admin();

$errors = [];
$flash = $_SESSION['google_forms_flash'] ?? '';
unset($_SESSION['google_forms_flash']);

/** Legge la configurazione multipla; migra in memoria le vecchie impostazioni singole. */
function gf_admin_items(): array
{
    $raw = cms_setting('google_forms_items', '');
    if (is_string($raw) && $raw !== '') {
        $decoded = json_decode($raw, true);
        if (is_array($decoded)) {
            $items = [];
            foreach ($decoded as $item) {
                if (!is_array($item)) continue;
                $id = strtolower(trim((string)($item['id'] ?? '')));
                $name = trim((string)($item['name'] ?? ''));
                $url = cms_google_forms_normalize_url((string)($item['url'] ?? ''));
                $height = (int)($item['height'] ?? 1200);
                if (!preg_match('/^[a-z0-9_-]{1,40}$/', $id) || $name === '' || $url === '') continue;
                if ($height < 400 || $height > 6000) $height = 1200;
                $items[$id] = ['id'=>$id, 'name'=>$name, 'url'=>$url, 'height'=>$height];
            }
            return $items;
        }
    }

    $legacyUrl = cms_google_forms_normalize_url((string)cms_setting('google_forms_embed_url', ''));
    if ($legacyUrl !== '') {
        $height = (int)cms_setting('google_forms_height', '1200');
        if ($height < 400 || $height > 6000) $height = 1200;
        return ['adesione'=>['id'=>'adesione','name'=>'Adesione','url'=>$legacyUrl,'height'=>$height]];
    }
    return [];
}

function gf_admin_save_items(array $items): void
{
    cms_set_setting('google_forms_items', json_encode(array_values($items), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
}

$items = gf_admin_items();
$editId = trim((string)($_GET['edit'] ?? ''));
$editing = ($editId !== '' && isset($items[$editId])) ? $items[$editId] : null;
$form = $editing ?? ['id'=>'','name'=>'','url'=>'','height'=>1200];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = (string)($_POST['action'] ?? 'save');
    $items = gf_admin_items();

    if ($action === 'delete') {
        $deleteId = strtolower(trim((string)($_POST['id'] ?? '')));
        if (isset($items[$deleteId])) {
            unset($items[$deleteId]);
            gf_admin_save_items($items);
            $_SESSION['google_forms_flash'] = 'Modulo eliminato.';
            header('Location: admin.php');
            exit;
        }
        $errors[] = 'Il modulo da eliminare non è stato trovato.';
    } else {
        $originalId = strtolower(trim((string)($_POST['edit_id'] ?? '')));
        $idInput = strtolower(trim((string)($_POST['google_forms_id'] ?? '')));
        $nameInput = trim((string)($_POST['google_forms_name'] ?? ''));
        $urlInput = trim((string)($_POST['google_forms_url'] ?? ''));
        $heightInput = trim((string)($_POST['google_forms_height'] ?? '1200'));
        $normalized = cms_google_forms_normalize_url($urlInput);

        if (!preg_match('/^[a-z0-9_-]{1,40}$/', $idInput)) {
            $errors[] = 'Identificatore non valido: usa lettere minuscole, numeri, trattini o underscore (massimo 40 caratteri).';
        }
        if ($nameInput === '' || (function_exists('mb_strlen') ? mb_strlen($nameInput) : strlen($nameInput)) > 80) {
            $errors[] = 'Inserisci un nome per il modulo (massimo 80 caratteri).';
        }
        if ($urlInput === '' || $normalized === '') {
            $errors[] = 'Indirizzo non valido. Usa il link Google Forms su docs.google.com che termina con /viewform.';
        }
        if (!preg_match('/^[0-9]{3,4}$/', $heightInput) || (int)$heightInput < 400 || (int)$heightInput > 6000) {
            $errors[] = 'L’altezza deve essere un numero compreso tra 400 e 6000 pixel.';
        }
        if ($originalId !== '' && !isset($items[$originalId])) {
            $errors[] = 'Il modulo da modificare non è stato trovato. Riapri la gestione e riprova.';
        }
        if ($originalId !== '' && $idInput !== $originalId) {
            $errors[] = 'L’identificatore di un modulo esistente non può essere modificato.';
        }
        if (($originalId === '' && isset($items[$idInput])) || ($originalId !== '' && isset($items[$idInput]) && $idInput !== $originalId)) {
            $errors[] = 'Questo identificatore è già utilizzato da un altro modulo.';
        }
        if ($originalId === '' && count($items) >= 50) {
            $errors[] = 'Hai raggiunto il limite massimo di 50 moduli.';
        }

        if (!$errors) {
            $items[$idInput] = ['id'=>$idInput, 'name'=>$nameInput, 'url'=>$normalized, 'height'=>(int)$heightInput];
            gf_admin_save_items($items);
            // Mantiene le vecchie chiavi per compatibilità con installazioni e contenuti precedenti.
            if (count($items) === 1) {
                cms_set_setting('google_forms_embed_url', $normalized);
                cms_set_setting('google_forms_height', (string)(int)$heightInput);
            }
            $_SESSION['google_forms_flash'] = 'Modulo Google Forms salvato.';
            header('Location: admin.php');
            exit;
        }
        $form = ['id'=>$idInput,'name'=>$nameInput,'url'=>$urlInput,'height'=>$heightInput];
        $editing = $originalId !== '';
    }
}
?>
<!doctype html>
<html lang="it">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<base href="../../admin/">
<title>Google Forms - MercurioCMS</title>
<link rel="stylesheet" href="../assets/css/admin.css">
<style>
.gf-code{display:block;padding:12px;border:1px solid #d8dee5;border-radius:8px;background:#f5f7f9;color:#18212b;font-family:monospace;overflow-wrap:anywhere}
.gf-help{color:#52606d;line-height:1.55}.gf-form{max-width:900px}.gf-form input[type=url],.gf-form input[type=number],.gf-form input[type=text]{width:100%;max-width:100%;box-sizing:border-box;padding:10px;border:1px solid #cbd5df;border-radius:6px}.gf-form label{display:block;margin:14px 0 6px;font-weight:600}.gf-table{width:100%;border-collapse:collapse}.gf-table th,.gf-table td{padding:10px;border-bottom:1px solid #e1e6eb;text-align:left;vertical-align:top}.gf-actions{display:flex;gap:12px;align-items:center;flex-wrap:wrap}.gf-inline{display:inline}
</style>
</head>
<body>
<?php $adminActive = 'plugins'; require dirname(__DIR__, 2) . '/admin/_sidebar.php'; ?>
<main class="container gf-form">
<h1>Google Forms</h1>
<p class="gf-help">Gestisci più moduli Google Forms e inserisci ciascuno nelle pagine desiderate con il suo identificatore. Non occorre incollare codice iframe.</p>
<?php if ($flash): ?><p class="notice"><?= e($flash) ?></p><?php endif; ?>
<?php if ($errors): ?><div class="error"><ul><?php foreach ($errors as $error): ?><li><?= e($error) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
<section class="panel">
<h2><?= $editing ? 'Modifica modulo' : 'Aggiungi un modulo' ?></h2>
<form method="post">
<input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
<input type="hidden" name="action" value="save">
<input type="hidden" name="edit_id" value="<?= e($editing ? $form['id'] : '') ?>">
<label for="google_forms_name">Nome del modulo</label>
<input id="google_forms_name" type="text" name="google_forms_name" value="<?= e($form['name']) ?>" placeholder="Adesione, Contatti, Richiesta informazioni" maxlength="80" required>
<label for="google_forms_id">Identificatore</label>
<input id="google_forms_id" type="text" name="google_forms_id" value="<?= e($form['id']) ?>" placeholder="adesione" pattern="[a-zA-Z0-9_-]{1,40}" maxlength="40" <?= $editing ? 'readonly' : 'required' ?>>
<p class="gf-help">Identificatore breve e univoco, senza spazi. Si usa nel segnaposto della pagina; non può essere cambiato dopo la creazione.</p>
<label for="google_forms_url">Indirizzo del modulo Google Forms</label>
<input id="google_forms_url" type="url" name="google_forms_url" value="<?= e($form['url']) ?>" placeholder="https://docs.google.com/forms/d/e/.../viewform" autocomplete="url" required>
<label for="google_forms_height">Altezza del modulo (pixel)</label>
<input id="google_forms_height" type="number" name="google_forms_height" min="400" max="6000" step="50" value="<?= e((string)$form['height']) ?>" required>
<p class="gf-actions"><button type="submit">Salva modulo</button><?php if ($editing): ?><a href="../plugins/google-forms/admin.php">Annulla modifica</a><?php endif; ?></p>
</form>
</section>
<section class="panel">
<h2>Moduli configurati (<?= count($items) ?>)</h2>
<?php if (!$items): ?><p class="gf-help">Non ci sono ancora moduli configurati.</p><?php else: ?>
<table class="gf-table"><thead><tr><th>Nome</th><th>Identificatore</th><th>Segnaposto</th><th>Azioni</th></tr></thead><tbody>
<?php foreach ($items as $item): ?><tr><td><?= e($item['name']) ?></td><td><code><?= e($item['id']) ?></code></td><td><code>[[MERCURIO_GOOGLE_FORMS:<?= e($item['id']) ?>]]</code></td><td class="gf-actions"><a href="../plugins/google-forms/admin.php?edit=<?= rawurlencode($item['id']) ?>">Modifica</a><form class="gf-inline" method="post" onsubmit="return confirm('Eliminare questo modulo?');"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= e($item['id']) ?>"><button type="submit">Elimina</button></form></td></tr><?php endforeach; ?>
</tbody></table><?php endif; ?>
</section>
<section class="panel">
<h2>Inserire un modulo in una pagina</h2>
<p>Inserisci nel contenuto della pagina il segnaposto corrispondente al modulo che vuoi mostrare:</p>
<ul><?php foreach ($items as $item): ?><li><strong><?= e($item['name']) ?>:</strong> <code class="gf-code">[[MERCURIO_GOOGLE_FORMS:<?= e($item['id']) ?>]]</code></li><?php endforeach; ?></ul>
<p class="gf-help">Per compatibilità, il vecchio segnaposto <code>[[MERCURIO_GOOGLE_FORMS]]</code> continua a visualizzare il primo modulo configurato. È mantenuto anche il vecchio span <code>&lt;span id="mercurio-google-form"&gt;&lt;/span&gt;</code>.</p>
<p class="gf-help">I moduli vengono caricati da Google e devono essere condivisi in modo da consentirne la visualizzazione.</p>
<p><a href="plugins.php">Torna a Gestione estensioni</a></p>
</section>
</main>
</body>
</html>
