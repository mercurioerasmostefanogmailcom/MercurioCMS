<?php
/** Archivio Download - estensione MercurioCMS. */
declare(strict_types=1);

if (!function_exists('ad_storage_dir')) {
    // Archivio condiviso del CMS: /uploads/archivi, accanto a documents e images.
    function ad_storage_dir(): string { return dirname(__DIR__, 2) . '/uploads/archivi'; }
    function ad_index_path(): string { return ad_storage_dir() . '/.index.json'; }

    function ad_ensure_storage(): void
    {
        $dir = ad_storage_dir();
        if (!is_dir($dir) && !mkdir($dir, 0755, true) && !is_dir($dir)) {
            throw new RuntimeException('Cartella uploads/archivi non disponibile.');
        }
        if (!is_file($dir . '/index.html')) @file_put_contents($dir . '/index.html', '');

        // ZIP pubblici, ma niente directory listing, accesso ai file nascosti o script eseguibili.
        $htaccess = "Options -Indexes\n<FilesMatch \"(?i)^(?:\\..*|.*\\.(?:php[0-9]?|phtml|phar|cgi|pl|py|sh|asp|aspx|jsp))$\">\nRequire all denied\n</FilesMatch>\n<IfModule mod_mime.c>\nAddType application/zip .zip\n</IfModule>\n";
        @file_put_contents($dir . '/.htaccess', $htaccess, LOCK_EX);

        // Migrazione automatica dagli archivi delle versioni precedenti.
        $sources = [dirname(__DIR__, 2) . '/upload/archivi', __DIR__ . '/files'];
        if (!is_file(ad_index_path())) {
            foreach ($sources as $sourceDir) {
                $sourceIndex = $sourceDir . '/.index.json';
                if (!is_file($sourceIndex)) continue;
                $sourceRows = json_decode((string)@file_get_contents($sourceIndex), true);
                if (!is_array($sourceRows)) continue;
                foreach ($sourceRows as $sourceRow) {
                    $filename = (string)($sourceRow['stored_filename'] ?? '');
                    if (ad_is_safe_zip_filename($filename) && is_file($sourceDir . '/' . $filename) && !is_link($sourceDir . '/' . $filename) && !is_file($dir . '/' . $filename)) {
                        @rename($sourceDir . '/' . $filename, $dir . '/' . $filename);
                    }
                }
                $json = json_encode(array_values($sourceRows), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
                if (is_string($json) && @file_put_contents(ad_index_path(), $json . "\n", LOCK_EX) !== false) break;
            }
        }
        if (!is_file(ad_index_path())) {
            $created = @file_put_contents(ad_index_path(), "[]\n", LOCK_EX);
            if ($created === false && !is_file(ad_index_path())) throw new RuntimeException('Archivio dati non scrivibile.');
        }
    }

    function ad_is_safe_zip_filename(string $filename): bool
    {
        return $filename !== ''
            && $filename === basename(str_replace('\\', '/', $filename))
            && !str_contains($filename, "\0")
            && preg_match('/\.zip$/i', $filename) === 1
            && !str_starts_with($filename, '.')
            && !preg_match('/[\x00-\x1F\x7F]/', $filename);
    }

    function ad_read_index(): array
    {
        ad_ensure_storage();
        $raw = @file_get_contents(ad_index_path());
        $data = is_string($raw) ? json_decode($raw, true) : null;
        return is_array($data) ? $data : [];
    }

    function ad_write_index(array $rows): void
    {
        ad_ensure_storage();
        $json = json_encode(array_values($rows), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
        if (!is_string($json)) throw new RuntimeException('Impossibile preparare l’indice dei file.');
        $path = ad_index_path();
        $tmp = $path . '.' . bin2hex(random_bytes(6)) . '.tmp';
        if (@file_put_contents($tmp, $json . "\n", LOCK_EX) === false) throw new RuntimeException('Impossibile scrivere l’indice dei file.');
        @chmod($tmp, 0644);
        if (!@rename($tmp, $path)) { @unlink($tmp); throw new RuntimeException('Impossibile aggiornare l’indice dei file.'); }
    }
}

ad_ensure_storage();

if (function_exists('cms_register_admin_menu')) {
    cms_register_admin_menu('archivio-download', 'Archivio Download', '../plugins/archivio-download/admin.php');
}
