<?php
declare(strict_types=1);
require_once dirname(__DIR__, 2) . '/app/bootstrap.php';
require_admin();
require_once __DIR__ . '/plugin.php';

$errors = [];
$flash = (string)($_SESSION['archivio_download_flash'] ?? '');
unset($_SESSION['archivio_download_flash']);
$maxBytes = 100 * 1024 * 1024;
$scriptPath = str_replace('\\', '/', (string)($_SERVER['SCRIPT_NAME'] ?? ''));
$cmsBasePath = preg_replace('~/plugins/archivio-download/admin\.php$~', '', $scriptPath);
if (!is_string($cmsBasePath) || $cmsBasePath === $scriptPath) {
    // Fallback per installazioni che includono la pagina admin da un router CMS.
    $documentRoot = realpath((string)($_SERVER['DOCUMENT_ROOT'] ?? ''));
    $cmsRoot = realpath(dirname(__DIR__, 2));
    if ($documentRoot && $cmsRoot && str_starts_with($cmsRoot, rtrim($documentRoot, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR)) {
        $relative = substr($cmsRoot, strlen(rtrim($documentRoot, DIRECTORY_SEPARATOR)));
        $cmsBasePath = '/' . str_replace(DIRECTORY_SEPARATOR, '/', trim($relative, DIRECTORY_SEPARATOR));
    } else {
        $cmsBasePath = '';
    }
}
$cmsBasePath = rtrim((string)$cmsBasePath, '/');
$adminBaseUrl = ($cmsBasePath === '' ? '' : $cmsBasePath) . '/admin/';
$publicBaseUrl = $cmsBasePath;

function ad_cms_public_url(string $storedFilename): string
{
    global $publicBaseUrl;
    if (!function_exists('ad_is_safe_zip_filename') || !ad_is_safe_zip_filename($storedFilename)) return '';
    $host = (string)($_SERVER['HTTP_HOST'] ?? $_SERVER['SERVER_NAME'] ?? '');
    // Accetta host DNS, IPv4 e IPv6 tra parentesi quadre, eventualmente con porta.
    if (!preg_match('/^(?:[A-Za-z0-9.-]+|\[[0-9A-Fa-f:]+\])(?::[0-9]{1,5})?$/D', $host)) return '';
    $https = (!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off')
        || strtolower((string)($_SERVER['REQUEST_SCHEME'] ?? '')) === 'https';
    $scheme = $https ? 'https' : 'http';
    $encodedPath = implode('/', array_map('rawurlencode', array_filter(explode('/', $publicBaseUrl), 'strlen')));
    $base = ($encodedPath === '' ? '' : '/' . $encodedPath);
    return $scheme . '://' . $host . $base . '/uploads/archivi/' . rawurlencode($storedFilename);
}

function ad_remove_stored_file(string $stored): void
{
    if (function_exists('ad_is_safe_zip_filename') && ad_is_safe_zip_filename($stored)) {
        $path = ad_storage_dir() . '/' . $stored;
        if (is_file($path) && !is_link($path)) @unlink($path);
    }
}

function ad_original_zip_name(string $name): string
{
    $name = basename(str_replace('\\', '/', $name));
    $name = preg_replace('/[\\x00-\\x1F\\x7F]/u', '', $name) ?? '';
    $name = trim($name, " .\t\n\r\0\x0B");
    if ($name === '' || $name === '.' || $name === '..') $name = 'file.zip';
    if (!preg_match('/\\.zip$/i', $name)) $name .= '.zip';
    if (str_starts_with($name, '.')) $name = 'file-' . ltrim($name, '.');
    return $name;
}

function ad_unique_stored_filename(string $original): string
{
    $dir = ad_storage_dir();
    $candidate = $original;
    $extension = '.zip';
    $stem = substr($original, 0, -strlen($extension));
    $suffix = 2;
    while (file_exists($dir . '/' . $candidate) || is_link($dir . '/' . $candidate)) {
        $candidate = $stem . ' (' . $suffix . ')' . $extension;
        $suffix++;
    }
    return $candidate;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = (string)($_POST['action'] ?? '');
    if ($action === 'upload') {
        $upload = $_FILES['zip_file'] ?? null;
        if (!is_array($upload) || (int)($upload['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            $errors[] = 'Seleziona un file ZIP e riprova il caricamento.';
        } elseif ((int)($upload['size'] ?? 0) <= 0 || (int)$upload['size'] > $maxBytes) {
            $errors[] = 'Il file è vuoto oppure supera il limite massimo di 100 MB.';
        } elseif (!preg_match('/\.zip$/i', (string)($upload['name'] ?? ''))) {
            $errors[] = 'Sono accettati esclusivamente file con estensione .zip.';
        } elseif (!is_uploaded_file((string)($upload['tmp_name'] ?? ''))) {
            $errors[] = 'Il file caricato non è stato ricevuto correttamente dal server.';
        } else {
            $head = file_get_contents((string)$upload['tmp_name'], false, null, 0, 4);
            $validSignature = is_string($head) && (str_starts_with($head, "PK\x03\x04") || str_starts_with($head, "PK\x05\x06") || str_starts_with($head, "PK\x07\x08"));
            if (!$validSignature) {
                $errors[] = 'Il file selezionato non sembra essere un archivio ZIP valido.';
            } else {
                $name = ad_original_zip_name((string)($upload['name'] ?? 'file.zip'));
                $stored = '';
                $destination = '';
                $reserved = false;
                try {
                    ad_ensure_storage();
                    $stored = ad_unique_stored_filename($name);
                    $destination = ad_storage_dir() . '/' . $stored;
                    // Riserva il nome in modo esclusivo per evitare collisioni tra caricamenti simultanei.
                    $reservation = @fopen($destination, 'x');
                    if ($reservation === false) throw new RuntimeException('Non è stato possibile riservare il nome del file.');
                    fclose($reservation);
                    $reserved = true;
                    if (!move_uploaded_file((string)$upload['tmp_name'], $destination)) {
                        @unlink($destination);
                        $reserved = false;
                        throw new RuntimeException('Non è stato possibile salvare il file sul server.');
                    }
                    @chmod($destination, 0644);
                    $rows = ad_read_index();
                    $nextId = 1;
                    foreach ($rows as $row) $nextId = max($nextId, (int)($row['id'] ?? 0) + 1);
                    $rows[] = ['id'=>$nextId, 'original_filename'=>$name, 'stored_filename'=>$stored, 'file_size'=>(int)$upload['size'], 'uploaded_at'=>date('Y-m-d H:i:s')];
                    ad_write_index($rows);
                    $_SESSION['archivio_download_flash'] = 'File compresso caricato correttamente.';
                    header('Location: ' . $scriptPath);
                    exit;
                } catch (Throwable $e) {
                    if ($reserved) ad_remove_stored_file($stored);
                    error_log('Archivio Download upload: ' . $e->getMessage());
                    $errors[] = 'Il file è stato ricevuto ma non è stato possibile registrarlo nell’archivio. Verificare i permessi di scrittura della cartella uploads/archivi.';
                }
            }
        }
    } elseif ($action === 'delete') {
        $id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        if (!$id) $errors[] = 'File da eliminare non valido.';
        else {
            try {
                $rows = ad_read_index();
                $found = false;
                foreach ($rows as $key => $row) {
                    if ((int)($row['id'] ?? 0) === (int)$id) {
                        ad_remove_stored_file((string)($row['stored_filename'] ?? ''));
                        unset($rows[$key]);
                        $found = true;
                        break;
                    }
                }
                if ($found) { ad_write_index($rows); $_SESSION['archivio_download_flash'] = 'File compresso eliminato.'; }
                header('Location: ' . $scriptPath);
                exit;
            } catch (Throwable $e) {
                error_log('Archivio Download delete: ' . $e->getMessage());
                $errors[] = 'Non è stato possibile aggiornare l’archivio dei file.';
            }
        }
    }
}

$files = ad_read_index();
usort($files, static fn($a, $b) => strcmp((string)($b['uploaded_at'] ?? ''), (string)($a['uploaded_at'] ?? '')) ?: ((int)($b['id'] ?? 0) <=> (int)($a['id'] ?? 0)));
?>
<!doctype html>
<html lang="it">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<base href="<?= e($adminBaseUrl) ?>">
<title>Archivio Download - MercurioCMS</title>
<link rel="stylesheet" href="../assets/css/admin.css">
<style>
.ad-wrap{max-width:1120px}.ad-help{color:#596675;line-height:1.55}.ad-upload input[type=file]{display:block;max-width:100%;margin:10px 0 16px}.ad-table{width:100%;border-collapse:collapse}.ad-table th,.ad-table td{text-align:left;padding:11px 9px;border-bottom:1px solid #e3e8ed;vertical-align:top}.ad-url{display:block;max-width:420px;overflow-wrap:anywhere;font-size:12px;background:#f3f6f8;padding:8px;border-radius:6px;margin-bottom:6px}.ad-filename{font-weight:600;overflow-wrap:anywhere}
</style>
</head>
<body>
<?php $adminActive = 'plugins'; require dirname(__DIR__, 2) . '/admin/_sidebar.php'; ?>
<main class="container ad-wrap">
<h1>Archivio Download</h1>
<p class="ad-help">Carica file compressi ZIP e ottieni un collegamento pubblico da inserire nelle pagine del sito. I file vengono conservati così come sono: non vengono aperti, estratti o installati.</p>
<?php if ($flash): ?><p class="notice"><?= e($flash) ?></p><?php endif; ?>
<?php if ($errors): ?><div class="error"><ul><?php foreach ($errors as $error): ?><li><?= e($error) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
<section class="panel">
<h2>Carica un file compresso</h2>
<form class="ad-upload" method="post" action="<?= e($scriptPath) ?>" enctype="multipart/form-data">
<input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="upload">
<label for="zip_file">Seleziona un file ZIP</label><input id="zip_file" type="file" name="zip_file" accept=".zip,application/zip" required>
<p class="ad-help">Sono accettati file .zip fino a 100 MB. Non è necessario che sul server sia installato ZipArchive.</p><button type="submit">Carica file</button>
</form>
</section>
<section class="panel"><h2>File caricati (<?= count($files) ?>)</h2>
<?php if (!$files): ?><p class="ad-help">Non hai ancora caricato file compressi.</p><?php else: ?>
<div style="overflow-x:auto"><table class="ad-table"><thead><tr><th>Nome file</th><th>Dimensione</th><th>Caricato il</th><th>Collegamento pubblico</th><th>Azioni</th></tr></thead><tbody>
<?php foreach ($files as $file): $url = ad_cms_public_url((string)($file['stored_filename'] ?? '')); ?><tr>
<td class="ad-filename"><?= e((string)$file['original_filename']) ?></td><td><?= number_format((int)$file['file_size'] / 1048576, 2, ',', '.') ?> MB</td><td><?= e((string)$file['uploaded_at']) ?></td>
<td><span class="ad-url"><?= e($url) ?></span><button type="button" class="secondary ad-copy" data-copy="<?= e($url) ?>">Copia collegamento</button></td>
<td><form method="post" action="<?= e($scriptPath) ?>" onsubmit="return confirm('Eliminare definitivamente questo file compresso?')"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$file['id'] ?>"><button type="submit" class="danger">Elimina</button></form></td>
</tr><?php endforeach; ?></tbody></table></div><?php endif; ?></section>
<p class="ad-help">Per usare un file in una pagina, copia il collegamento e assegnalo al testo o al pulsante che vuoi rendere cliccabile. Il download è pubblico; caricamento ed eliminazione sono riservati agli amministratori.</p>
</main>
<script>
document.querySelectorAll('button[data-copy]').forEach(function(button){button.addEventListener('click',function(){var value=button.getAttribute('data-copy')||'';if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(value).then(function(){button.textContent='Copiato';}).catch(function(){window.prompt('Copia il collegamento:',value);});}else{window.prompt('Copia il collegamento:',value);}});});
</script>
</body></html>
