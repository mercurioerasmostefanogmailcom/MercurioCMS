<?php
/** Download pubblico di un file compresso. */
declare(strict_types=1);
require_once dirname(__DIR__, 2) . '/app/bootstrap.php';

if (!cms_table_exists('plugins')) { http_response_code(404); exit('Download non disponibile.'); }
$active = $pdo->prepare('SELECT is_active FROM ' . cms_table('plugins') . ' WHERE plugin_id = ? LIMIT 1');
$active->execute(['archivio-download']);
if ((int)$active->fetchColumn() !== 1) { http_response_code(404); exit('Download non disponibile.'); }
require_once __DIR__ . '/plugin.php';

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
if (!$id) { http_response_code(404); exit('File non trovato.'); }
$row = null;
foreach (ad_read_index() as $item) if ((int)($item['id'] ?? 0) === (int)$id) { $row = $item; break; }
if (!$row || !function_exists('ad_is_safe_zip_filename') || !ad_is_safe_zip_filename((string)($row['stored_filename'] ?? ''))) { http_response_code(404); exit('File non trovato.'); }
$base = realpath(ad_storage_dir());
$file = realpath(ad_storage_dir() . '/' . $row['stored_filename']);
if (!$base || !$file || !str_starts_with($file, $base . DIRECTORY_SEPARATOR) || !is_file($file) || !is_readable($file)) { http_response_code(404); exit('File non disponibile.'); }
$name = basename(str_replace('\\', '/', (string)($row['original_filename'] ?? 'file.zip')));
$asciiName = preg_replace('/[^A-Za-z0-9._-]/', '_', $name) ?: 'file.zip';
if (!str_ends_with(strtolower($asciiName), '.zip')) $asciiName .= '.zip';
while (ob_get_level() > 0) ob_end_clean();
header('Content-Type: application/zip');
header('Content-Disposition: attachment; filename="' . $asciiName . '"; filename*=UTF-8\'\'' . rawurlencode($name));
header('Content-Length: ' . (string)filesize($file));
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, no-store, no-cache, must-revalidate');
header('Pragma: no-cache');
readfile($file);
exit;
