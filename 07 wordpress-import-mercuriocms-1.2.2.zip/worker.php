<?php
declare(strict_types=1);
// Worker CLI opzionale: consente di continuare l'importazione anche senza browser aperto.
if (PHP_SAPI !== 'cli') { http_response_code(404); exit('Not found'); }
@set_time_limit(55);
ignore_user_abort(true);
require_once dirname(__DIR__,2).'/app/bootstrap.php';
require_once dirname(__DIR__,2).'/app/zip-reader.php';
require_once __DIR__.'/lib.php';
wpi_ensure_schema();
$deadline=microtime(true)+50;
while(microtime(true)<$deadline){
    $row=$pdo->query("SELECT job_id FROM ".cms_table('wp_import_jobs')." WHERE status='running' ORDER BY updated_at ASC LIMIT 1")->fetch(PDO::FETCH_ASSOC);
    if(!$row)break;
    try{$progress=wpi_process_batch((string)$row['job_id']);if(($progress['status']??'')!=='running')continue;}
    catch(Throwable $e){error_log('MercurioCMS WordPress import worker: '.$e->getMessage());usleep(400000);}
}
echo "Worker Importazione WordPress: esecuzione terminata.\n";
