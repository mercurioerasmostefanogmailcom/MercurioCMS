<?php
declare(strict_types=1);
require_once __DIR__ . '/lib.php';
if (function_exists('cms_register_admin_menu')) {
    cms_register_admin_menu('wordpress-import', 'Importazione WordPress', '../plugins/wordpress-import/admin.php');
}
