<?php
/** Importazione documenti per MercurioCMS 1.0.0. */
declare(strict_types=1);
require_once __DIR__ . '/lib.php';
if (function_exists('cms_register_admin_menu')) {
    cms_register_admin_menu('document-to-page', 'Importazione documenti', '../plugins/document-to-page/admin.php');
}
