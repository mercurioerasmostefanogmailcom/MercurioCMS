<?php
declare(strict_types=1);

function dcp_root(): string { return dirname(__DIR__, 2); }
function dcp_table(): string { return cms_table('document_page_imports'); }
function dcp_login_table(): string { return cms_table('document_page_login_attempts'); }
function dcp_setting_key(): string { return 'document_to_page_config'; }
function dcp_h(string $s): string { return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function dcp_is_active(): bool {
    global $pdo;
    if (!cms_table_exists('plugins')) return false;
    $q=$pdo->prepare('SELECT is_active FROM '.cms_table('plugins').' WHERE plugin_id=? LIMIT 1');
    $q->execute(['document-to-page']); return (int)$q->fetchColumn()===1;
}
function dcp_base_path(): string {
    $script=str_replace('\\','/',(string)($_SERVER['SCRIPT_NAME']??''));
    $suffix='/plugins/document-to-page/'; $pos=strrpos($script,$suffix);
    return $pos!==false?rtrim(substr($script,0,$pos),'/'):'';
}
function dcp_admin_url(string $file='dashboard.php'): string { return dcp_base_path().'/admin/'.ltrim($file,'/'); }
function dcp_mobile_url(string $token): string {
    $host=trim((string)($_SERVER['HTTP_HOST']??''));
    if($host===''||!preg_match('/^(?:[A-Za-z0-9.-]+|\[[0-9A-Fa-f:]+\])(?::[0-9]{1,5})?$/D',$host)) $host=trim((string)($_SERVER['SERVER_NAME']??''));
    if($host===''||!preg_match('/^(?:[A-Za-z0-9.-]+|\[[0-9A-Fa-f:]+\])(?::[0-9]{1,5})?$/D',$host)) throw new RuntimeException('Impossibile determinare il dominio del sito per creare il collegamento mobile.');
    $https=(!empty($_SERVER['HTTPS'])&&strtolower((string)$_SERVER['HTTPS'])!=='off')||strtolower((string)($_SERVER['REQUEST_SCHEME']??''))==='https';
    return ($https?'https':'http').'://'.$host.dcp_base_path().'/plugins/document-to-page/phone.php?k='.rawurlencode($token);
}
function dcp_secure_transport(): bool {
    $https=(!empty($_SERVER['HTTPS'])&&strtolower((string)$_SERVER['HTTPS'])!=='off')||strtolower((string)($_SERVER['REQUEST_SCHEME']??''))==='https';
    $host=strtolower((string)($_SERVER['HTTP_HOST']??''));$host=preg_replace('/:[0-9]+$/','',$host)??$host;
    return $https||in_array($host,['localhost','127.0.0.1','::1'],true);
}
function dcp_default_config(): array { return ['category_id'=>0,'page_status'=>'draft','secret_hash'=>'','max_file_bytes'=>20971520,'max_images'=>12,'max_image_bytes'=>5242880]; }
function dcp_config(): array { $raw=cms_setting(dcp_setting_key(),'');$saved=is_string($raw)?json_decode($raw,true):null;return array_merge(dcp_default_config(),is_array($saved)?$saved:[]); }
function dcp_save_config(array $c): void { cms_set_setting(dcp_setting_key(),json_encode($c,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)); }
function dcp_ensure_schema(): void {
    global $pdo;
    if(!cms_table_exists('document_page_imports')) $pdo->exec('CREATE TABLE '.dcp_table().' (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      file_hash CHAR(64) NOT NULL,
      original_name VARCHAR(255) NOT NULL,
      file_type VARCHAR(12) NOT NULL,
      title VARCHAR(220) NOT NULL DEFAULT \'\',
      page_id BIGINT UNSIGNED NULL,
      status VARCHAR(20) NOT NULL DEFAULT \'imported\',
      note TEXT NULL,
      imported_at DATETIME NOT NULL,
      PRIMARY KEY(id), UNIQUE KEY uq_document_hash(file_hash), KEY idx_document_page(page_id), KEY idx_document_date(imported_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');
    if(!cms_table_exists('document_page_login_attempts')) $pdo->exec('CREATE TABLE '.dcp_login_table().' (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, ip_hash CHAR(64) NOT NULL, attempted_at DATETIME NOT NULL,
      PRIMARY KEY(id), KEY idx_document_login_ip_time(ip_hash,attempted_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');
}

/* Lettura ZIP: usa ZipArchive se disponibile e il lettore ZIP nativo del CMS come fallback. */
final class DcpArchive {
    private object $zip; private bool $native=false; private int $entries=0;
    public function __construct(string $path) {
        if(class_exists('ZipArchive')) { $z=new ZipArchive();if($z->open($path)!==true)throw new RuntimeException('Il documento non è un archivio valido o risulta danneggiato.');$this->zip=$z;$this->native=true;$this->entries=(int)$z->numFiles; }
        else { $reader=dcp_root().'/app/zip-reader.php';if(!is_file($reader))throw new RuntimeException('Lettore ZIP MercurioCMS non disponibile.');require_once $reader;$z=new CmsZipReader();if(!$z->open($path))throw new RuntimeException('Archivio non valido, compresso con metodo non supportato o danneggiato.');$this->zip=$z;$this->entries=(int)$z->numFiles; }
        if($this->entries<1||$this->entries>1800)throw new RuntimeException('Il documento contiene un numero eccessivo di elementi interni.');
    }
    public function get(string $name,int $max=30000000): string {
        $st=$this->zip->statName($name);if(!$st)return '';$size=(int)($st['size']??0);if($size<0||$size>$max)throw new RuntimeException('Un elemento interno del documento supera il limite consentito.');
        $v=$this->zip->getFromName($name);if(!is_string($v))return '';if(strlen($v)>$max)throw new RuntimeException('Un elemento interno del documento supera il limite consentito.');return $v;
    }
    public function has(string $name): bool { return (bool)$this->zip->statName($name); }
    public function close(): void { if(method_exists($this->zip,'close'))$this->zip->close(); }
}

/* Parser XML compatto: non richiede DOM, SimpleXML o XMLReader. Disabilita DTD/entità esterne. */
final class DcpXmlNode { public string $name='';public string $local='';public array $attrs=[];public array $children=[];public string $text=''; }
function dcp_xml_parse(string $xml): DcpXmlNode {
    if(strlen($xml)>25000000||preg_match('/<!DOCTYPE|<!ENTITY/i',$xml)) throw new RuntimeException('Documento XML non valido o contenente dichiarazioni non consentite.');
    $root=new DcpXmlNode();$root->name='#root';$root->local='#root';$stack=[$root];
    preg_match_all('/<!--[\s\S]*?-->|<\?[\s\S]*?\?>|<!\[CDATA\[[\s\S]*?\]\]>|<[^>]+>|[^<]+/u',$xml,$tokens);
    foreach($tokens[0] as $tok){
      if(str_starts_with($tok,'<!--')||str_starts_with($tok,'<?'))continue;
      if(str_starts_with($tok,'<![CDATA[')){ $stack[count($stack)-1]->text.=substr($tok,9,-3);continue; }
      if(str_starts_with($tok,'</')){if(count($stack)>1)array_pop($stack);continue;}
      if(str_starts_with($tok,'<!'))continue;
      if(str_starts_with($tok,'<')){
        $inside=trim(substr($tok,1,-1));$self=str_ends_with($inside,'/');if($self)$inside=rtrim(substr($inside,0,-1));
        if(!preg_match('/^([A-Za-z_][A-Za-z0-9_.:-]*)/',$inside,$m))continue;
        $n=new DcpXmlNode();$n->name=$m[1];$parts=explode(':',$n->name);$n->local=end($parts);
        $rest=substr($inside,strlen($m[1]));if(preg_match_all('/([A-Za-z_][A-Za-z0-9_.:-]*)\s*=\s*(?:"([^"]*)"|\'([^\']*)\')/s',$rest,$am,PREG_SET_ORDER))foreach($am as $a){$k=$a[1];$kp=explode(':',$k);$n->attrs[end($kp)]=html_entity_decode($a[2]!==''?$a[2]:($a[3]??''),ENT_QUOTES|ENT_XML1,'UTF-8');$n->attrs[$k]=html_entity_decode($a[2]!==''?$a[2]:($a[3]??''),ENT_QUOTES|ENT_XML1,'UTF-8');}
        $stack[count($stack)-1]->children[]=$n;if(!$self)$stack[]=$n;
      } else { $stack[count($stack)-1]->text.=html_entity_decode($tok,ENT_QUOTES|ENT_XML1,'UTF-8'); }
    }
    return $root;
}
function dcp_children(DcpXmlNode $n,string $local): array { return array_values(array_filter($n->children,fn($c)=>$c->local===$local)); }
function dcp_first(DcpXmlNode $n,string $local): ?DcpXmlNode { foreach($n->children as $c)if($c->local===$local)return $c;return null; }
function dcp_find_first(DcpXmlNode $n,string $local): ?DcpXmlNode { foreach($n->children as $c){if($c->local===$local)return $c;$found=dcp_find_first($c,$local);if($found)return $found;}return null; }
function dcp_desc(DcpXmlNode $n,string $local): array { $out=[];foreach($n->children as $c){if($c->local===$local)$out[]=$c;$out=array_merge($out,dcp_desc($c,$local));}return $out; }
function dcp_text(DcpXmlNode $n): string { $s=$n->text;foreach($n->children as $c)$s.=dcp_text($c);return $s; }
function dcp_attr(DcpXmlNode $n,string $key,string $default=''): string { return (string)($n->attrs[$key]??$n->attrs['r:'.$key]??$n->attrs['xlink:'.$key]??$default); }
function dcp_safe_href(string $href): string {
    $href=trim(html_entity_decode($href,ENT_QUOTES|ENT_HTML5,'UTF-8'));if($href===''||preg_match('/[\x00-\x20\x7f]/',$href))return '';
    if(str_starts_with($href,'#'))return preg_match('/^#[A-Za-z0-9_.:-]{1,200}$/',$href)?$href:'';
    $p=parse_url($href);if(!$p||empty($p['scheme']))return '';$scheme=strtolower((string)$p['scheme']);if(!in_array($scheme,['http','https','mailto','tel'],true))return '';
    if(in_array($scheme,['http','https'],true)&&empty($p['host']))return '';if(isset($p['user'])||isset($p['pass']))return '';return $href;
}
function dcp_a(string $href,string $text): string { $u=dcp_safe_href($href);return $u!==''?'<a href="'.dcp_h($u).'" target="_blank" rel="nofollow noopener">'.$text.'</a>':$text; }
function dcp_zip_rels(DcpArchive $z,string $source): array {
    $dir=dirname($source);$base=basename($source);$rel=($dir==='.'?'':$dir.'/').'_rels/'.$base.'.rels';$raw=$z->get($rel,3000000);if($raw==='')return [];$root=dcp_xml_parse($raw);$map=[];
    foreach(dcp_desc($root,'Relationship') as $r){$id=dcp_attr($r,'Id');$target=dcp_attr($r,'Target');$mode=strtolower(dcp_attr($r,'TargetMode'));if($id===''||$target==='')continue;$map[$id]=['target'=>$target,'external'=>$mode==='external'];}return $map;
}
function dcp_rel_path(string $source,string $target): string {
    if(str_starts_with($target,'/'))$joined=ltrim($target,'/');else $joined=dirname($source).'/'.$target;
    $parts=[];foreach(explode('/',$joined) as $p){if($p===''||$p==='.')continue;if($p==='..'){array_pop($parts);continue;}$parts[]=$p;}return implode('/',$parts);
}
function dcp_image_add(DcpArchive $z,string $path,array &$images,int &$total): string {
    if(count($images)>=12)return ''; $parts=[];foreach(explode('/',str_replace('\\','/',$path)) as $part){if($part===''||$part==='.')continue;if($part==='..'){if(!$parts)return '';array_pop($parts);continue;}$parts[]=$part;}$path=implode('/',$parts);if($path==='')return '';$raw=$z->get($path,5242880);if($raw==='')return '';$info=@getimagesizefromstring($raw);if(!$info)return '';$mime=strtolower((string)($info['mime']??''));$ext=['image/jpeg'=>'jpg','image/png'=>'png','image/gif'=>'gif','image/webp'=>'webp'][$mime]??null;if(!$ext)return '';
    if($total+strlen($raw)>15728640)return '';$total+=strlen($raw);$key='dcpimg'.(count($images)+1);$images[$key]=['data'=>base64_encode($raw),'mime'=>$mime,'ext'=>$ext,'name'=>basename($path)];return $key;
}
function dcp_img(string $key,array $images,string $alt=''): string { if(!isset($images[$key]))return '';return '<img src="@@DCP_IMAGE:'.$key.'@@" alt="'.dcp_h($alt).'">'; }
function dcp_xml_run(DcpXmlNode $run,array $rels,DcpArchive $z,array &$images,int &$total,string $source): string {
    $out='';foreach($run->children as $c){if($c->local==='t'||$c->local==='delText')$out.=dcp_h(dcp_text($c));elseif($c->local==='tab')$out.='&nbsp;&nbsp;&nbsp;';elseif($c->local==='br'||$c->local==='cr')$out.='<br>';elseif($c->local==='drawing'||$c->local==='pict'||$c->local==='object'){
        foreach(dcp_desc($c,'blip') as $b){$id=dcp_attr($b,'embed');$r=$rels[$id]??null;if($r&&!$r['external']){$k=dcp_image_add($z,dcp_rel_path($source,$r['target']),$images,$total);if($k!=='')$out.=dcp_img($k,$images);}}
      }elseif($c->local==='rPr')continue;
    }
    $pr=dcp_first($run,'rPr');if($pr){if(dcp_first($pr,'b'))$out='<strong>'.$out.'</strong>';if(dcp_first($pr,'i'))$out='<em>'.$out.'</em>';if(dcp_first($pr,'u'))$out='<u>'.$out.'</u>';if(dcp_first($pr,'strike'))$out='<s>'.$out.'</s>';}
    return $out;
}
function dcp_docx_node(DcpXmlNode $n,array $rels,DcpArchive $z,array &$images,int &$total,string $source): string {
    $out='';foreach($n->children as $c){if($c->local==='p')$out.=dcp_docx_paragraph($c,$rels,$z,$images,$total,$source);elseif($c->local==='tbl')$out.=dcp_docx_table($c,$rels,$z,$images,$total,$source);}
    return $out;
}
function dcp_docx_paragraph(DcpXmlNode $p,array $rels,DcpArchive $z,array &$images,int &$total,string $source): string {
    $out='';foreach($p->children as $c){if($c->local==='r')$out.=dcp_xml_run($c,$rels,$z,$images,$total,$source);elseif($c->local==='hyperlink'){$id=dcp_attr($c,'id');$href='';if(isset($rels[$id])&&$rels[$id]['external'])$href=$rels[$id]['target'];else{$anchor=dcp_attr($c,'anchor');if($anchor!=='')$href='#'.$anchor;}$inner='';foreach($c->children as $r)if($r->local==='r')$inner.=dcp_xml_run($r,$rels,$z,$images,$total,$source);$out.=dcp_a($href,$inner);}}
    $style='';$ppr=dcp_first($p,'pPr');$ps=$ppr?dcp_first($ppr,'pStyle'):null;if($ps){$v=dcp_attr($ps,'val');if(preg_match('/^Heading([1-6])$/i',$v,$m))$style='h'.min(6,(int)$m[1]);elseif(stripos($v,'title')!==false)$style='h1';}
    if($out==='')return '';if($style!=='')return '<'.$style.'>'.$out.'</'.$style.'>';
    if($ppr&&dcp_first($ppr,'numPr'))return '<p>• '.$out.'</p>';return '<p>'.$out.'</p>';
}
function dcp_docx_table(DcpXmlNode $t,array $rels,DcpArchive $z,array &$images,int &$total,string $source): string {
    $out='<table><tbody>';foreach(dcp_children($t,'tr') as $row){$out.='<tr>';foreach(dcp_children($row,'tc') as $cell){$out.='<td>'.dcp_docx_node($cell,$rels,$z,$images,$total,$source).'</td>';}$out.='</tr>';}$out.='</tbody></table>';return $out;
}
function dcp_parse_docx(DcpArchive $z,array &$images,int &$total): array {
    $raw=$z->get('word/document.xml',20000000);if($raw==='')throw new RuntimeException('Il documento Word non contiene word/document.xml.');$root=dcp_xml_parse($raw);$rels=dcp_zip_rels($z,'word/document.xml');$body=dcp_find_first($root,'body');if(!$body)throw new RuntimeException('Struttura DOCX non riconosciuta.');$html=dcp_docx_node($body,$rels,$z,$images,$total,'word/document.xml');
    $props=$z->get('docProps/core.xml',500000);$title='';if($props!==''){$p=dcp_xml_parse($props);$t=dcp_find_first($p,'title');if($t)$title=trim(dcp_text($t));}return ['title'=>$title,'content'=>$html];
}
function dcp_parse_xlsx(DcpArchive $z,array &$images,int &$total): array {
    $wbRaw=$z->get('xl/workbook.xml',5000000);if($wbRaw==='')throw new RuntimeException('Cartella di lavoro XLSX non valida.');$wb=dcp_xml_parse($wbRaw);$wbRel=dcp_zip_rels($z,'xl/workbook.xml');$shared=[];$sr=$z->get('xl/sharedStrings.xml',15000000);if($sr!==''){foreach(dcp_desc(dcp_xml_parse($sr),'si') as $si)$shared[]=dcp_text($si);}
    $out='';$sheets=array_slice(dcp_desc($wb,'sheet'),0,30);if(!$sheets)throw new RuntimeException('Il file Excel non contiene fogli leggibili.');
    foreach($sheets as $sheet){$rid=dcp_attr($sheet,'id');$rel=$wbRel[$rid]??null;if(!$rel||$rel['external'])continue;$path=dcp_rel_path('xl/workbook.xml',$rel['target']);$raw=$z->get($path,18000000);if($raw==='')continue;$root=dcp_xml_parse($raw);$rels=dcp_zip_rels($z,$path);$links=[];foreach(dcp_desc($root,'hyperlink') as $h){$ref=dcp_attr($h,'ref');$id=dcp_attr($h,'id');$loc=dcp_attr($h,'location');if($ref!=='')$links[$ref]=$loc!==''?'#'.$loc:(isset($rels[$id])&&$rels[$id]['external']?$rels[$id]['target']:'');}
      $out.='<h2>'.dcp_h(dcp_attr($sheet,'name','Foglio')).'</h2><table><tbody>';$rows=dcp_desc($root,'row');$rowCount=0;
      foreach($rows as $row){if(++$rowCount>500)break;$out.='<tr>';foreach(dcp_children($row,'c') as $cell){$ref=dcp_attr($cell,'r');$type=dcp_attr($cell,'t');$v=dcp_first($cell,'v');$val=$v?dcp_text($v):'';if($type==='s')$val=$shared[(int)$val]??'';elseif($type==='inlineStr'){$is=dcp_first($cell,'is');$val=$is?dcp_text($is):'';}elseif($type==='b')$val=$val==='1'?'Sì':'No';$text=dcp_h(trim($val));$href=$links[$ref]??'';if($href!=='')$text=dcp_a($href,$text);$out.='<td>'.$text.'</td>';}$out.='</tr>';}$out.='</tbody></table>';
      // Immagini ancorate nel foglio: recupera i disegni e li mostra dopo la tabella.
      foreach(dcp_desc($root,'drawing') as $dr){$id=dcp_attr($dr,'id');if(!isset($rels[$id])||$rels[$id]['external'])continue;$dp=dcp_rel_path($path,$rels[$id]['target']);$drawRaw=$z->get($dp,4000000);if($drawRaw==='')continue;$draw=dcp_xml_parse($drawRaw);$drels=dcp_zip_rels($z,$dp);foreach(dcp_desc($draw,'blip') as $b){$iid=dcp_attr($b,'embed');if(isset($drels[$iid])&&!$drels[$iid]['external']){$k=dcp_image_add($z,dcp_rel_path($dp,$drels[$iid]['target']),$images,$total);if($k!=='')$out.=dcp_img($k,$images);}}}
    }
    return ['title'=>'Foglio di calcolo importato','content'=>$out];
}
function dcp_parse_pptx(DcpArchive $z,array &$images,int &$total): array {
    $raw=$z->get('ppt/presentation.xml',5000000);if($raw==='')throw new RuntimeException('Presentazione PPTX non valida.');$root=dcp_xml_parse($raw);$rels=dcp_zip_rels($z,'ppt/presentation.xml');$out='';$slides=dcp_desc($root,'sldId');$num=0;
    foreach($slides as $s){$id=dcp_attr($s,'id');$r=$rels[$id]??null;if(!$r||$r['external'])continue;$path=dcp_rel_path('ppt/presentation.xml',$r['target']);$xml=$z->get($path,12000000);if($xml==='')continue;$slide=dcp_xml_parse($xml);$sr=dcp_zip_rels($z,$path);$num++;$out.='<section><h2>Diapositiva '.$num.'</h2>';
      foreach(dcp_desc($slide,'sp') as $shape){$tx=dcp_first($shape,'txBody');if(!$tx)continue;foreach(dcp_children($tx,'p') as $p){$line='';foreach(dcp_desc($p,'t') as $t)$line.=dcp_h(dcp_text($t));if($line!=='')$out.='<p>'.$line.'</p>';}}
      foreach(dcp_desc($slide,'graphicFrame') as $frame){$tbl=dcp_find_first($frame,'tbl');if($tbl){$out.='<table><tbody>';foreach(dcp_children($tbl,'tr') as $row){$out.='<tr>';foreach($row->children as $cell)if($cell->local==='tc'){$v='';foreach(dcp_desc($cell,'t') as $t)$v.=dcp_h(dcp_text($t));$out.='<td>'.$v.'</td>';}$out.='</tr>';}$out.='</tbody></table>';}}
      foreach(dcp_desc($slide,'pic') as $pic){$blips=dcp_desc($pic,'blip');$blip=$blips[0]??null;if($blip){$iid=dcp_attr($blip,'embed');if(isset($sr[$iid])&&!$sr[$iid]['external']){$k=dcp_image_add($z,dcp_rel_path($path,$sr[$iid]['target']),$images,$total);if($k!=='')$out.=dcp_img($k,$images);}}}
      $out.='</section>';
    }
    if($out==='')throw new RuntimeException('Non è stato possibile leggere il testo delle diapositive.');return ['title'=>'Presentazione importata','content'=>$out];
}
function dcp_odf_render(DcpXmlNode $n,DcpArchive $z,string $source,array &$images,int &$total,int $depth=0): string {
    if($depth>40)return ''; $out='';$tag=$n->local;
    if($tag==='p'||$tag==='h'){$inner=dcp_h($n->text);foreach($n->children as $c)$inner.=dcp_odf_render($c,$z,$source,$images,$total,$depth+1);$level=(int)preg_replace('/\D/','',(string)($n->attrs['text:outline-level']??'1'));$level=max(1,min(6,$level));return $tag==='h'?'<h'.$level.'>'.$inner.'</h'.$level.'>':'<p>'.$inner.'</p>';}
    if($tag==='a'){$href=dcp_attr($n,'href');$inner='';foreach($n->children as $c)$inner.=dcp_odf_render($c,$z,$source,$images,$total,$depth+1);return dcp_a($href,$inner);}
    if($tag==='image'){$href=dcp_attr($n,'href');$key=dcp_image_add($z,dcp_rel_path($source,$href),$images,$total);return $key!==''?dcp_img($key,$images):'';}
    if($tag==='table'){$out='<table><tbody>';foreach(dcp_children($n,'table-row') as $row)$out.=dcp_odf_render($row,$z,$source,$images,$total,$depth+1);return $out.'</tbody></table>';}
    if($tag==='table-row'){$out='<tr>';foreach($n->children as $c)if(in_array($c->local,['table-cell','covered-table-cell'],true))$out.=dcp_odf_render($c,$z,$source,$images,$total,$depth+1);return $out.'</tr>';}
    if($tag==='table-cell'||$tag==='covered-table-cell'){$repeat=max(1,min(30,(int)($n->attrs['table:number-columns-repeated']??1)));$inner='';foreach($n->children as $c)$inner.=dcp_odf_render($c,$z,$source,$images,$total,$depth+1);return str_repeat('<td>'.$inner.'</td>',$repeat);}
    if($tag==='list'){$inner='';foreach($n->children as $c)$inner.=dcp_odf_render($c,$z,$source,$images,$total,$depth+1);return '<ul>'.$inner.'</ul>';}
    if($tag==='list-item'){$inner='';foreach($n->children as $c)$inner.=dcp_odf_render($c,$z,$source,$images,$total,$depth+1);return '<li>'.$inner.'</li>';}
    if(in_array($tag,['span','s','line-break','tab'],true)){if($tag==='line-break')return '<br>';if($tag==='tab')return '&nbsp;&nbsp;&nbsp;';$inner=dcp_h($n->text);foreach($n->children as $c)$inner.=dcp_odf_render($c,$z,$source,$images,$total,$depth+1);if($tag==='s')return str_repeat('&nbsp;',max(1,min(20,(int)($n->attrs['text:c']??1))));return $inner;}
    if($tag==='frame'){$inner='';foreach($n->children as $c)$inner.=dcp_odf_render($c,$z,$source,$images,$total,$depth+1);return $inner;}
    $out=dcp_h($n->text);foreach($n->children as $c)$out.=dcp_odf_render($c,$z,$source,$images,$total,$depth+1);return $out;
}
function dcp_parse_odf(DcpArchive $z,string $ext,array &$images,int &$total): array {
    $raw=$z->get('content.xml',25000000);if($raw==='')throw new RuntimeException('Documento OpenDocument non valido: content.xml mancante.');$root=dcp_xml_parse($raw);$body=dcp_find_first($root,'body');if(!$body)throw new RuntimeException('Struttura OpenDocument non riconosciuta.');$out='';
    if($ext==='odt'){$text=dcp_first($body,'text');if($text)$out=dcp_odf_render($text,$z,'content.xml',$images,$total);}
    elseif($ext==='ods'){$spread=dcp_first($body,'spreadsheet');if($spread){foreach(array_slice(dcp_children($spread,'table'),0,30) as $tab){$name=dcp_attr($tab,'name','Foglio');$out.='<h2>'.dcp_h($name).'</h2><table><tbody>';foreach(array_slice(dcp_children($tab,'table-row'),0,500) as $row){$out.=dcp_odf_render($row,$z,'content.xml',$images,$total);}$out.='</tbody></table>';}}}
    else {$pres=dcp_first($body,'presentation');if($pres){foreach(array_slice(dcp_children($pres,'page'),0,200) as $i=>$page){$out.='<section><h2>Diapositiva '.($i+1).'</h2>'.dcp_odf_render($page,$z,'content.xml',$images,$total).'</section>';}}}
    if($out==='')throw new RuntimeException('Il documento non contiene contenuti testuali o tabelle leggibili.');return ['title'=>'Documento importato','content'=>$out];
}
function dcp_detect_type(string $ext): string { return ['docx'=>'Word','xlsx'=>'Excel','pptx'=>'PowerPoint','odt'=>'OpenDocument Text','ods'=>'OpenDocument Spreadsheet','odp'=>'OpenDocument Presentation'][$ext]??'Documento'; }
function dcp_parse_file(string $path,string $originalName): array {
    $ext=strtolower(pathinfo($originalName,PATHINFO_EXTENSION));$allowed=['docx','xlsx','pptx','odt','ods','odp'];if(!in_array($ext,$allowed,true))throw new RuntimeException('Formato non supportato. Sono ammessi soltanto DOCX, XLSX, PPTX, ODT, ODS e ODP.');
    $z=new DcpArchive($path);$images=[];$total=0;
    try {
      $parsed=match($ext){'docx'=>dcp_parse_docx($z,$images,$total),'xlsx'=>dcp_parse_xlsx($z,$images,$total),'pptx'=>dcp_parse_pptx($z,$images,$total),default=>dcp_parse_odf($z,$ext,$images,$total)};
    } finally {$z->close();}
    $html=trim((string)$parsed['content']);if($html==='')throw new RuntimeException('Il documento non contiene contenuti importabili.');
    $title=trim((string)($parsed['title']??''));if($title===''||in_array($title,['Foglio di calcolo importato','Presentazione importata','Documento importato'],true)){$metaZip=new DcpArchive($path);try{$core=$metaZip->get('docProps/core.xml',500000);if($core==='')$core=$metaZip->get('meta.xml',1000000);if($core!==''){$meta=dcp_xml_parse($core);$metaTitle=dcp_find_first($meta,'title');if($metaTitle&&trim(dcp_text($metaTitle))!=='')$title=trim(dcp_text($metaTitle));}}finally{$metaZip->close();}}if($title==='')$title=trim(pathinfo($originalName,PATHINFO_FILENAME));if($title==='')$title='Documento importato';
    $title=function_exists('mb_substr')?mb_substr($title,0,220,'UTF-8'):substr($title,0,220);
    $html=preg_replace('/@@DCP_IMAGE:([A-Za-z0-9]+)@@/','@@DCP_IMAGE:$1@@',$html)??$html;
    return ['title'=>$title,'content'=>$html,'images'=>$images,'type'=>dcp_detect_type($ext),'extension'=>$ext,'file_hash'=>hash_file('sha256',$path),'original_name'=>(function_exists('mb_substr')?mb_substr(basename($originalName),0,255,'UTF-8'):substr(basename($originalName),0,255))];
}
function dcp_preview_content(array $data): string {
    $html=(string)$data['content'];foreach($data['images'] as $key=>$im){$uri='data:'.$im['mime'].';base64,'.$im['data'];$html=str_replace('@@DCP_IMAGE:'.$key.'@@',dcp_h($uri),$html);}return $html;
}

function dcp_history_by_hash(string $hash): ?array { global $pdo;$q=$pdo->prepare('SELECT * FROM '.dcp_table().' WHERE file_hash=? LIMIT 1');$q->execute([$hash]);$r=$q->fetch();return $r?:null; }
function dcp_create_page(array $cfg,array $data): int {
    global $pdo;$category=(int)$cfg['category_id'];$q=$pdo->prepare('SELECT id FROM '.cms_table('categories').' WHERE id=? LIMIT 1');$q->execute([$category]);if(!$q->fetchColumn())throw new RuntimeException('Seleziona una categoria valida nelle impostazioni dell’estensione.');
    $hash=(string)$data['file_hash'];if(!preg_match('/^[a-f0-9]{64}$/',$hash))throw new RuntimeException('Impronta del documento non valida.');$createdFiles=[];$pdo->beginTransaction();
    try {
      $lock=$pdo->prepare('SELECT * FROM '.dcp_table().' WHERE file_hash=? FOR UPDATE');$lock->execute([$hash]);$old=$lock->fetch();if($old)throw new RuntimeException('Questo documento risulta già importato (pagina ID '.(int)$old['page_id'].').');
      $dir=dcp_root().'/uploads/images';if(!is_dir($dir)&&!mkdir($dir,0755,true)&&!is_dir($dir))throw new RuntimeException('Cartella uploads/images non disponibile.');$html=(string)$data['content'];$count=0;
      foreach($data['images'] as $key=>$im){$marker='@@DCP_IMAGE:'.$key.'@@';if(strpos($html,$marker)===false)continue;if($count>=(int)($cfg['max_images']??12))break;$bytes=base64_decode((string)$im['data'],true);if(!is_string($bytes)||$bytes===''||strlen($bytes)>(int)($cfg['max_image_bytes']??5242880))continue;$info=@getimagesizefromstring($bytes);if(!$info)continue;$mime=strtolower((string)($info['mime']??''));$ext=['image/jpeg'=>'jpg','image/png'=>'png','image/gif'=>'gif','image/webp'=>'webp'][$mime]??null;if(!$ext)continue;
        $stored=bin2hex(random_bytes(16)).'.'.$ext;$path=$dir.'/'.$stored;if(file_put_contents($path,$bytes,LOCK_EX)===false)throw new RuntimeException('Impossibile salvare un’immagine estratta dal documento.');@chmod($path,0644);$createdFiles[]=$path;
        $name=basename((string)($im['name']??('immagine.'.$ext)));$q=$pdo->prepare('INSERT INTO '.cms_table('media').' (original_name,stored_name,media_type,mime_type,file_size,created_at,deleted_at) VALUES (?,?,?,?,?,?,NULL)');$q->execute([$name,$stored,'image',$mime,strlen($bytes),date('Y-m-d H:i:s')]);$count++;
        $html=str_replace($marker,'uploads/images/'.$stored,$html);
      }
      $html=preg_replace('/<img\b[^>]*src="@@DCP_IMAGE:[A-Za-z0-9]+@@"[^>]*>/i','',$html)??$html;
      $html=preg_replace('/@@DCP_IMAGE:[A-Za-z0-9]+@@/','',$html)??$html;
      $html=sanitize_page_html($html);$plain=trim(preg_replace('/\s+/u',' ',html_entity_decode(strip_tags($html),ENT_QUOTES|ENT_HTML5,'UTF-8'))??'');$excerpt=function_exists('mb_substr')?mb_substr($plain,0,500,'UTF-8'):substr($plain,0,500);
      $title=trim((string)$data['title']);if($title==='')$title='Documento importato';$title=function_exists('mb_substr')?mb_substr($title,0,220,'UTF-8'):substr($title,0,220);$base=slugify($title);$slug=$base;$n=2;while(true){$s=$pdo->prepare('SELECT id FROM '.cms_table('pages').' WHERE slug=?');$s->execute([$slug]);if(!$s->fetch())break;$slug=$base.'-'.$n++;}
      $now=date('Y-m-d H:i:s');$status=$cfg['page_status']==='published'?'published':'draft';$ins=$pdo->prepare('INSERT INTO '.cms_table('pages').' (title,slug,content,excerpt,background_image,hide_title,hide_category,status,created_at,updated_at,published_at,deleted_at) VALUES (?,?,?,?,NULL,0,0,?,?,?,?,NULL)');$ins->execute([$title,$slug,$html,$excerpt,$status,$now,$now,$status==='published'?$now:null]);$pageId=(int)$pdo->lastInsertId();$pdo->prepare('INSERT INTO '.cms_table('page_categories').' (page_id,category_id) VALUES (?,?)')->execute([$pageId,$category]);
      $i=$pdo->prepare('INSERT INTO '.dcp_table().' (file_hash,original_name,file_type,title,page_id,status,note,imported_at) VALUES (?,?,?,?,?,\'imported\',NULL,?)');$i->execute([$hash,basename((string)$data['original_name']),(string)$data['extension'],$title,$pageId,$now]);$pdo->commit();return $pageId;
    } catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();foreach($createdFiles as $f)if(is_file($f))@unlink($f);throw $e;}
}
function dcp_admin_session_valid(): bool { global $pdo;if(empty($_SESSION['admin_id']))return false;$q=$pdo->prepare('SELECT is_active FROM '.cms_table('admins').' WHERE id=? LIMIT 1');$q->execute([(int)$_SESSION['admin_id']]);if((int)$q->fetchColumn()!==1){$_SESSION=[];if(session_status()===PHP_SESSION_ACTIVE)session_destroy();return false;}return true; }
function dcp_mobile_login(): ?string {
    global $pdo;if($_SERVER['REQUEST_METHOD']!=='POST'||($_POST['dcp_action']??'')!=='mobile_login')return null;csrf_check();$ipHash=hash('sha256',(string)($_SERVER['REMOTE_ADDR']??'unknown').'|document-to-page');$q=$pdo->prepare('SELECT COUNT(*) FROM '.dcp_login_table().' WHERE ip_hash=? AND attempted_at>=?');$q->execute([$ipHash,date('Y-m-d H:i:s',time()-900)]);if((int)$q->fetchColumn()>=5)return 'Troppi tentativi. Riprova tra 15 minuti.';
    $u=trim((string)($_POST['username']??''));$q=$pdo->prepare('SELECT id,username,password_hash,role,display_name,is_active FROM '.cms_table('admins').' WHERE username=? LIMIT 1');$q->execute([$u]);$a=$q->fetch();if($a&&(int)$a['is_active']===1&&password_verify((string)($_POST['password']??''),(string)$a['password_hash'])){$pdo->prepare('DELETE FROM '.dcp_login_table().' WHERE ip_hash=?')->execute([$ipHash]);session_regenerate_id(true);$_SESSION['admin_id']=(int)$a['id'];$_SESSION['admin_username']=$a['username'];$_SESSION['admin_role']=$a['role'];$_SESSION['admin_display_name']=$a['display_name']??'';$_SESSION['dcp_mobile_last_activity']=time();return null;}
    $pdo->prepare('INSERT INTO '.dcp_login_table().' (ip_hash,attempted_at) VALUES (?,?)')->execute([$ipHash,date('Y-m-d H:i:s')]);return 'Credenziali amministrative non valide.';
}
function dcp_mobile_session_valid(): bool { if(!dcp_admin_session_valid())return false;$now=time();$last=(int)($_SESSION['dcp_mobile_last_activity']??0);if($last>0&&$now-$last>1800){unset($_SESSION['admin_id'],$_SESSION['admin_username'],$_SESSION['admin_role'],$_SESSION['admin_display_name'],$_SESSION['dcp_mobile_last_activity']);return false;}$_SESSION['dcp_mobile_last_activity']=$now;return true; }
