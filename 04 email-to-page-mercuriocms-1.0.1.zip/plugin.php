<?php
/** Pubblicazione via e-mail per MercurioCMS 1.0.0. */
declare(strict_types=1);
require_once __DIR__ . '/lib.php';
if (function_exists('cms_register_admin_menu')) {
    cms_register_admin_menu('email-to-page', 'Pubblicazione via e-mail', '../plugins/email-to-page/admin.php');
}
