<?php
declare(strict_types=1);

function etp_root(): string { return dirname(__DIR__, 2); }
function etp_setting_key(): string { return 'email_to_page_config'; }
function etp_table(): string { return cms_table('email_imports'); }
function etp_is_active(): bool {
    global $pdo;
    if(!cms_table_exists('plugins')) return false;
    $q=$pdo->prepare('SELECT is_active FROM '.cms_table('plugins').' WHERE plugin_id=? LIMIT 1'); $q->execute(['email-to-page']);
    return (int)$q->fetchColumn()===1;
}
function etp_ensure_schema(): void {
    global $pdo;
    if (!cms_table_exists('email_imports')) {
        $pdo->exec('CREATE TABLE ' . etp_table() . ' (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            mailbox_key CHAR(64) NOT NULL,
            folder_name VARCHAR(190) NOT NULL,
            uid_validity VARCHAR(40) NOT NULL DEFAULT "",
            imap_uid VARCHAR(40) NOT NULL DEFAULT "",
            uid_fingerprint CHAR(64) NOT NULL,
            message_id VARCHAR(255) NOT NULL DEFAULT "",
            message_id_hash CHAR(64) NOT NULL DEFAULT "",
            content_sha256 CHAR(64) NOT NULL,
            sender VARCHAR(255) NOT NULL DEFAULT "",
            subject VARCHAR(220) NOT NULL,
            mail_date DATETIME NULL,
            page_id BIGINT UNSIGNED NULL,
            imported_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY uq_mail_uid_fingerprint (uid_fingerprint),
            KEY idx_mail_message_hash (mailbox_key, message_id_hash),
            KEY idx_mail_hash (mailbox_key, content_sha256),
            KEY idx_mail_page (page_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');
    }
    if (!cms_table_exists('email_login_attempts')) {
        $pdo->exec('CREATE TABLE ' . cms_table('email_login_attempts') . ' (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            ip_hash CHAR(64) NOT NULL,
            attempted_at DATETIME NOT NULL,
            PRIMARY KEY (id), KEY idx_email_login_ip_time (ip_hash, attempted_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');
    }
}
function etp_default_config(): array {
    return ['host'=>'','port'=>993,'security'=>'ssl','username'=>'','password_enc'=>'','folder'=>'INBOX','timeout'=>20,'allowed_senders'=>'','max_messages'=>30,'category_id'=>0,'page_status'=>'draft','secret_hash'=>''];
}
function etp_config(): array {
    $raw = cms_setting(etp_setting_key(), '');
    $saved = is_string($raw) ? json_decode($raw, true) : null;
    return array_merge(etp_default_config(), is_array($saved) ? $saved : []);
}
function etp_save_config(array $config): void {
    cms_set_setting(etp_setting_key(), json_encode($config, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
}
function etp_crypto_key(): string {
    // La chiave deriva dalla configurazione privata del CMS: nessun file segreto viene esposto nella document root.
    global $config;
    $db = is_array($config['db'] ?? null) ? $config['db'] : [];
    $seed = implode('|', [(string)($db['host']??''),(string)($db['name']??''),(string)($db['user']??''),(string)($db['password']??''),(string)($config['table_prefix']??''),'MercurioCMS-email-to-page-v1']);
    return hash('sha256', $seed, true);
}
function etp_encrypt_password(string $password): string {
    if ($password === '') return '';
    if (!function_exists('openssl_encrypt')) throw new RuntimeException('Per proteggere la password è necessario OpenSSL.');
    $iv = random_bytes(12); $tag = '';
    $cipher = openssl_encrypt($password, 'aes-256-gcm', etp_crypto_key(), OPENSSL_RAW_DATA, $iv, $tag);
    if (!is_string($cipher)) throw new RuntimeException('Impossibile proteggere la password e-mail.');
    return base64_encode($iv . $tag . $cipher);
}
function etp_decrypt_password(string $encoded): string {
    if ($encoded === '') return '';
    $raw = base64_decode($encoded, true);
    if (!is_string($raw) || strlen($raw) < 29) throw new RuntimeException('Password e-mail salvata non valida. Reinseriscila nelle impostazioni.');
    $plain = openssl_decrypt(substr($raw, 28), 'aes-256-gcm', etp_crypto_key(), OPENSSL_RAW_DATA, substr($raw, 0, 12), substr($raw, 12, 16));
    if (!is_string($plain)) throw new RuntimeException('Non riesco a decifrare la password e-mail. Reinseriscila nelle impostazioni.');
    return $plain;
}
function etp_mailbox_key(array $c): string { return hash('sha256', strtolower(trim((string)$c['host']) . '|' . trim((string)$c['username']))); }
function etp_h(string $s): string { return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function etp_csrf(): string { return csrf_token(); }
function etp_safe_date(string $value): ?string {
    $ts = strtotime($value); return $ts === false ? null : date('Y-m-d H:i:s', $ts);
}
function etp_header_decode(string $value): string {
    if (function_exists('iconv_mime_decode')) {
        $decoded = @iconv_mime_decode($value, ICONV_MIME_DECODE_CONTINUE_ON_ERROR, 'UTF-8');
        if (is_string($decoded)) return trim($decoded);
    }
    return trim(preg_replace_callback('/=\?([^?]+)\?([bq])\?([^?]*)\?=/i', function($m) {
        $v = strtolower($m[2]) === 'b' ? base64_decode($m[3], true) : quoted_printable_decode(str_replace('_', ' ', $m[3]));
        if (!is_string($v)) return $m[0];
        $out = @iconv($m[1], 'UTF-8//IGNORE', $v); return is_string($out) ? $out : $v;
    }, $value) ?? $value);
}
function etp_parse_headers(string $raw): array {
    $lines = preg_split("/\r?\n/", trim($raw)) ?: []; $headers = []; $last = '';
    foreach ($lines as $line) {
        if (($line[0] ?? '') === ' ' || ($line[0] ?? '') === "\t") { if ($last !== '') $headers[$last] .= ' ' . trim($line); continue; }
        $p = strpos($line, ':'); if ($p === false) continue;
        $last = strtolower(trim(substr($line, 0, $p))); $headers[$last] = trim(substr($line, $p + 1));
    }
    foreach ($headers as $k => $v) $headers[$k] = etp_header_decode($v);
    return $headers;
}
function etp_split_message(string $raw): array {
    $p = preg_split("/\r?\n\r?\n/", $raw, 2); return [etp_parse_headers($p[0] ?? ''), $p[1] ?? ''];
}
function etp_param(string $header, string $name): string {
    if (preg_match('/(?:^|;)\s*' . preg_quote($name, '/') . '\s*=\s*(?:"((?:[^"\\\\]|\\\\.)*)"|([^;\s]*))/i', $header, $m)) return stripcslashes((string)($m[1] !== '' ? $m[1] : ($m[2] ?? '')));
    return '';
}
function etp_decode_part(string $body, string $encoding): string {
    $encoding = strtolower(trim($encoding));
    if ($encoding === 'base64') { $v = base64_decode(preg_replace('/\s+/', '', $body) ?? '', true); return is_string($v) ? $v : ''; }
    if ($encoding === 'quoted-printable') return quoted_printable_decode($body);
    return $body;
}
function etp_to_utf8(string $text, string $charset): string {
    $charset = trim($charset, " \t\"'");
    if ($charset !== '' && strcasecmp($charset, 'utf-8') !== 0 && function_exists('iconv')) {
        $converted = @iconv($charset, 'UTF-8//IGNORE', $text); if (is_string($converted)) return $converted;
    }
    return $text;
}
function etp_mime_collect(string $raw, array &$out, int $depth = 0): void {
    if ($depth > 12) return;
    [$headers, $body] = etp_split_message($raw);
    $ct = (string)($headers['content-type'] ?? 'text/plain');
    $type = strtolower(trim(strtok($ct, ';') ?: 'text/plain'));
    $transfer = (string)($headers['content-transfer-encoding'] ?? '');
    $disp = (string)($headers['content-disposition'] ?? '');
    $boundary = etp_param($ct, 'boundary');
    if (str_starts_with($type, 'multipart/') && $boundary !== '') {
        $parts = preg_split('/\r?\n--' . preg_quote($boundary, '/') . '(?:--)?\s*(?:\r?\n|$)/', "\r\n" . $body);
        if (is_array($parts)) foreach ($parts as $part) { $part = trim($part, "\r\n"); if ($part !== '' && !str_starts_with($part, '--')) etp_mime_collect($part, $out, $depth + 1); }
        return;
    }
    $decoded = etp_decode_part($body, $transfer);
    $charset = etp_param($ct, 'charset');
    if ($type === 'text/html' && stripos($disp, 'attachment') === false) { $out['html'][] = etp_to_utf8($decoded, $charset); return; }
    if ($type === 'text/plain' && stripos($disp, 'attachment') === false) { $out['plain'][] = etp_to_utf8($decoded, $charset); return; }
    if (str_starts_with($type, 'image/')) {
        $out['images'][] = ['data'=>$decoded,'type'=>$type,'name'=>etp_header_decode(etp_param($disp, 'filename') ?: etp_param($ct, 'name')),'cid'=>trim((string)($headers['content-id'] ?? ''), "<> \t"),'inline'=>stripos($disp, 'inline') !== false || isset($headers['content-id'])];
    }
}
function etp_parse_mail(string $raw): array {
    [$headers] = etp_split_message($raw);
    $parts = ['html'=>[],'plain'=>[],'images'=>[]]; etp_mime_collect($raw, $parts);
    $html = '';
    if ($parts['html']) $html = implode("\n", $parts['html']);
    elseif ($parts['plain']) $html = '<p>' . nl2br(etp_h(implode("\n\n", $parts['plain'])), false) . '</p>';
    return [
        'headers'=>$headers,
        'subject'=>trim((string)($headers['subject'] ?? '(senza oggetto)')),
        'from'=>trim((string)($headers['from'] ?? '')),
        'date'=>trim((string)($headers['date'] ?? '')),
        'message_id'=>trim((string)($headers['message-id'] ?? '')),
        'html'=>$html,
        'images'=>$parts['images'],
        'raw_hash'=>hash('sha256', $raw)
    ];
}

/** Client IMAP minimale su socket TLS: non richiede l'estensione PHP imap. */
class ETP_ImapClient {
    private $stream = null; private int $tag = 0; private string $uidValidity = '';
    public function connect(array $c): void {
        $host = trim((string)$c['host']); $port = (int)$c['port']; $security = (string)$c['security'];
        if ($host === '' || !preg_match('/^[A-Za-z0-9.-]+$/', $host) || $port < 1 || $port > 65535) throw new RuntimeException('Server o porta IMAP non validi.');
        $context = stream_context_create(['ssl'=>['verify_peer'=>true,'verify_peer_name'=>true,'peer_name'=>$host,'SNI_enabled'=>true]]);
        $target = $security === 'ssl' ? 'ssl://' . $host . ':' . $port : 'tcp://' . $host . ':' . $port;
        $errno = 0; $errstr = '';
        $this->stream = @stream_socket_client($target, $errno, $errstr, max(5,(int)$c['timeout']), STREAM_CLIENT_CONNECT, $context);
        if (!$this->stream) throw new RuntimeException('Connessione IMAP non riuscita: ' . $errstr . ' (' . $errno . ').');
        stream_set_timeout($this->stream, max(5,(int)$c['timeout']));
        $greeting = fgets($this->stream); if (!is_string($greeting) || (stripos($greeting, '* OK') !== 0 && stripos($greeting, '* PREAUTH') !== 0)) throw new RuntimeException('Il server IMAP non ha risposto correttamente.');
        if ($security === 'starttls') {
            $this->command('STARTTLS');
            if (!@stream_socket_enable_crypto($this->stream, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) throw new RuntimeException('Avvio TLS sulla connessione IMAP non riuscito.');
        }
        if (stripos($greeting, '* PREAUTH') !== 0) {
            $user = $this->quote((string)$c['username']); $pass = $this->quote(etp_decrypt_password((string)$c['password_enc']));
            $this->command('LOGIN ' . $user . ' ' . $pass);
        }
        $folder = $this->quote((string)$c['folder']);
        $selected = $this->command('SELECT ' . $folder);
        if (preg_match('/\[UIDVALIDITY\s+(\d+)\]/i', $selected['raw'], $m)) $this->uidValidity = $m[1];
        if ($this->uidValidity === '') $this->uidValidity = '0';
    }
    private function quote(string $s): string { return '"' . str_replace(['\\','"'], ['\\\\','\\"'], $s) . '"'; }
    private function command(string $command): array {
        if (!$this->stream) throw new RuntimeException('Connessione IMAP chiusa.');
        $tag = 'A' . str_pad((string)++$this->tag, 4, '0', STR_PAD_LEFT);
        if (fwrite($this->stream, $tag . ' ' . $command . "\r\n") === false) throw new RuntimeException('Invio comando IMAP non riuscito.');
        $raw = ''; $literals = [];
        while (!feof($this->stream)) {
            $line = fgets($this->stream);
            if (!is_string($line)) break;
            $raw .= $line;
            if (preg_match('/\{(\d+)\+?\}\r?\n$/', $line, $m)) {
                $left = (int)$m[1]; if ($left > 15 * 1024 * 1024) throw new RuntimeException('Messaggio e-mail troppo grande (limite 15 MB).');
                $literal = '';
                while ($left > 0) { $chunk = fread($this->stream, min(8192, $left)); if (!is_string($chunk) || $chunk === '') throw new RuntimeException('Risposta IMAP incompleta.'); $literal .= $chunk; $left -= strlen($chunk); }
                $literals[] = $literal; $raw .= $literal; continue;
            }
            if (preg_match('/^' . preg_quote($tag, '/') . '\s+(OK|NO|BAD)\b/i', $line, $m)) {
                if (strtoupper($m[1]) !== 'OK') throw new RuntimeException('Il server IMAP ha rifiutato il comando: ' . trim($line));
                return ['raw'=>$raw,'literals'=>$literals];
            }
        }
        throw new RuntimeException('Risposta IMAP interrotta o non valida.');
    }
    public function uidValidity(): string { return $this->uidValidity; }
    public function searchUids(): array {
        $r = $this->command('UID SEARCH ALL');
        if (!preg_match('/\* SEARCH([^\r\n]*)/i', $r['raw'], $m)) return [];
        preg_match_all('/\d+/', $m[1], $ids); return array_values(array_unique($ids[0] ?? []));
    }
    public function fetchHeader(string $uid): string { $r = $this->command('UID FETCH ' . (int)$uid . ' (BODY.PEEK[HEADER])'); return (string)($r['literals'][0] ?? ''); }
    public function fetchRaw(string $uid): string { $r = $this->command('UID FETCH ' . (int)$uid . ' (BODY.PEEK[])'); return (string)($r['literals'][0] ?? ''); }
    public function close(): void { if ($this->stream) { try { $this->command('LOGOUT'); } catch (Throwable $e) {} fclose($this->stream); $this->stream = null; } }
    public function __destruct() { $this->close(); }
}
function etp_connect(array $c): ETP_ImapClient {
    $client = new ETP_ImapClient(); $client->connect($c); return $client;
}
function etp_imported_row(array $c, string $uidValidity, string $uid, string $messageId = '', string $hash = ''): ?array {
    global $pdo;
    $table = etp_table(); $key = etp_mailbox_key($c); $folder = (string)$c['folder'];
    $uidFingerprint=hash('sha256',$key.'|'.$folder.'|'.$uidValidity.'|'.$uid);
    $q = $pdo->prepare("SELECT * FROM $table WHERE uid_fingerprint=? LIMIT 1");
    $q->execute([$uidFingerprint]); $row = $q->fetch(); if ($row) return $row;
    if ($messageId !== '') { $q = $pdo->prepare("SELECT * FROM $table WHERE mailbox_key=? AND message_id_hash=? ORDER BY id DESC LIMIT 1"); $q->execute([$key,hash('sha256',$messageId)]); $row=$q->fetch(); if($row)return $row; }
    if ($hash !== '') { $q = $pdo->prepare("SELECT * FROM $table WHERE mailbox_key=? AND content_sha256=? ORDER BY id DESC LIMIT 1"); $q->execute([$key,$hash]); $row=$q->fetch(); if($row)return $row; }
    return null;
}
function etp_allowed_sender(array $c, string $from): bool {
    $rules = preg_split('/[\r\n,;]+/', (string)$c['allowed_senders']) ?: [];
    $rules = array_values(array_filter(array_map('trim',$rules), fn($v)=>$v!==''));
    if (!$rules) return true;
    preg_match('/[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}/i', $from, $m); $email = strtolower($m[0] ?? '');
    foreach ($rules as $rule) { $rule = strtolower($rule); if ($email !== '' && ($email === $rule || (str_starts_with($rule,'@') && str_ends_with($email,$rule)))) return true; }
    return false;
}
function etp_list_messages(array $c): array {
    $client = etp_connect($c); $result=[];
    try {
        $uids = array_slice(array_reverse($client->searchUids()), 0, max(1,min(100,(int)$c['max_messages'])));
        foreach ($uids as $uid) {
            $header = $client->fetchHeader((string)$uid); if ($header === '') continue;
            $h = etp_parse_headers($header); $from=(string)($h['from']??''); if(!etp_allowed_sender($c,$from)) continue;
            $messageId=trim((string)($h['message-id']??''));
            $old=etp_imported_row($c,$client->uidValidity(),(string)$uid,$messageId);
            if ($old) continue;
            $result[]=['uid'=>(string)$uid,'subject'=>(string)($h['subject']??'(senza oggetto)'),'from'=>$from,'date'=>(string)($h['date']??''),'message_id'=>$messageId];
        }
    } finally { $client->close(); }
    return $result;
}
function etp_fetch_message(array $c, string $uid): array {
    $client=etp_connect($c);
    try { $raw=$client->fetchRaw($uid); if($raw==='') throw new RuntimeException('Il messaggio selezionato non è più disponibile.'); return ['mail'=>etp_parse_mail($raw),'uid_validity'=>$client->uidValidity()]; }
    finally { $client->close(); }
}
function etp_store_images(array $images): array {
    global $pdo;
    $map=[]; $created=[]; $records=[]; $dir=etp_root().'/uploads/images';
    if(!is_dir($dir) && !mkdir($dir,0755,true) && !is_dir($dir)) throw new RuntimeException('Cartella uploads/images non disponibile.');
    foreach($images as $img) {
        $data=(string)($img['data']??''); if($data==='' || strlen($data)>10*1024*1024) continue;
        $info=@getimagesizefromstring($data); if(!$info) continue;
        $mime=strtolower((string)($info['mime']??'')); $extMap=['image/jpeg'=>'jpg','image/png'=>'png','image/gif'=>'gif','image/webp'=>'webp'];
        if(!isset($extMap[$mime])) continue; $ext=$extMap[$mime];
        $original=basename(str_replace('\\','/',(string)($img['name']??''))); if($original==='' || $original==='.') $original='immagine-email.'.$ext;
        $stored=bin2hex(random_bytes(16)).'.'.$ext; $path=$dir.'/'.$stored;
        if(file_put_contents($path,$data,LOCK_EX)===false) throw new RuntimeException('Non riesco a salvare un’immagine ricevuta.');
        @chmod($path,0644); $created[]=$path;
        $stmt=$pdo->prepare('INSERT INTO '.cms_table('media').' (original_name,stored_name,media_type,mime_type,file_size,created_at,deleted_at) VALUES (?,?,?,?,?,?,NULL)');
        $stmt->execute([$original,$stored,'image',$mime,strlen($data),date('Y-m-d H:i:s')]);
        $url='uploads/images/'.$stored; $cid=trim((string)($img['cid']??''));
        if($cid!=='') $map[$cid]=$url;
        $records[]=['url'=>$url,'name'=>$original,'cid'=>$cid,'inline'=>(bool)($img['inline']??false)];
    }
    return [$map,$created,$records];
}
function etp_build_page_content(array $mail, array &$createdFiles): string {
    [$cidMap,$createdFiles,$records]=etp_store_images($mail['images']);
    $html=(string)$mail['html'];
    foreach($cidMap as $cid=>$url) $html=preg_replace('/cid:'.preg_quote($cid,'/').'/i', etp_h($url), $html) ?? $html;
    // Non importare fogli CSS esterni o stili arbitrari provenienti dal messaggio.
    $html=preg_replace('~<style\b[^>]*>.*?</style\s*>~is','',$html)??$html;
    $html=preg_replace('~<link\b[^>]*>~i','',$html)??$html;
    $html=preg_replace('/\s+style\s*=\s*(?:"[^"]*"|\'[^\']*\')/i','',$html)??$html;
    foreach($records as $record) {
        $cid=$record['cid'];
        if($cid!=='' && isset($cidMap[$cid]) && stripos($html,$cidMap[$cid])!==false) continue;
        $name=etp_h($record['name']);
        $html .= '<figure><img src="'.etp_h($record['url']).'" alt="'.$name.'"><figcaption>'.$name.'</figcaption></figure>';
    }
    return sanitize_page_html($html);
}
function etp_preview_html(array $mail): string {
    $html=(string)$mail['html']; $replacements=[]; $used=[]; $i=0;
    foreach($mail['images'] as $img) {
        $cid=trim((string)($img['cid']??'')); $data=(string)($img['data']??'');
        $info=$data!==''?@getimagesizefromstring($data):false; $mime=is_array($info)?strtolower((string)($info['mime']??'')):'';
        if(!$info || strlen($data)>2*1024*1024 || !in_array($mime,['image/jpeg','image/png','image/gif','image/webp'],true)) continue;
        $placeholder='uploads/images/preview-email-'.$i++.'.'.(['image/jpeg'=>'jpg','image/png'=>'png','image/gif'=>'gif','image/webp'=>'webp'][$mime]);
        $dataUrl='data:'.$mime.';base64,'.base64_encode($data);
        if($cid!=='') $html=preg_replace('/cid:'.preg_quote($cid,'/').'/i',$placeholder,$html)??$html;
        $replacements[$placeholder]=$dataUrl;
        if(strpos($html,$placeholder)===false) $html.='<figure><img src="'.$placeholder.'" alt="'.etp_h((string)($img['name']??'Immagine allegata')).'"></figure>';
    }
    $html=preg_replace('~<style\b[^>]*>.*?</style\s*>~is','',$html)??$html;
    $html=preg_replace('~<link\b[^>]*>~i','',$html)??$html;
    $html=preg_replace('/\s+style\s*=\s*(?:"[^"]*"|\'[^\']*\')/i','',$html)??$html;
    $safe=sanitize_page_html($html);
    foreach($replacements as $placeholder=>$dataUrl) $safe=str_replace('src="'.$placeholder.'"','src="'.$dataUrl.'"',$safe);
    return $safe;
}
function etp_create_page(array $c, string $uid, string $uidValidity, array $mail): int {
    global $pdo;
    $pageTable=cms_table('pages'); $linkTable=cms_table('page_categories'); $catTable=cms_table('categories');
    $category=(int)$c['category_id']; $q=$pdo->prepare("SELECT id FROM $catTable WHERE id=? LIMIT 1"); $q->execute([$category]);
    if(!$q->fetchColumn()) throw new RuntimeException('Scegli una categoria valida nelle impostazioni del plugin prima di importare.');
    $mailbox=etp_mailbox_key($c); $folder=(string)$c['folder']; $msgId=substr((string)$mail['message_id'],0,255); $hash=(string)$mail['raw_hash'];
    $old=etp_imported_row($c,$uidValidity,$uid,$msgId,$hash); if($old) throw new RuntimeException('Questo messaggio risulta già importato.');
    $title=trim((string)$mail['subject']); if($title==='') $title='Messaggio e-mail';
    $title=function_exists('mb_substr')?mb_substr($title,0,220,'UTF-8'):substr($title,0,220);
    $contentFiles=[];
    $pdo->beginTransaction();
    try {
        $content=etp_build_page_content($mail,$contentFiles);
        $plain=trim(preg_replace('/\s+/u',' ',html_entity_decode(strip_tags($content),ENT_QUOTES|ENT_HTML5,'UTF-8'))??'');
        $excerpt=function_exists('mb_substr')?mb_substr($plain,0,500,'UTF-8'):substr($plain,0,500);
        $base=slugify($title); $slug=$base; $n=2;
        while(true){$s=$pdo->prepare("SELECT id FROM $pageTable WHERE slug=?");$s->execute([$slug]);if(!$s->fetch())break;$slug=$base.'-'.$n++;}
        $now=date('Y-m-d H:i:s'); $pageDate=etp_safe_date((string)$mail['date'])??$now; $status=$c['page_status']==='published'?'published':'draft';
        $stmt=$pdo->prepare("INSERT INTO $pageTable (title,slug,content,excerpt,background_image,hide_title,hide_category,status,created_at,updated_at,published_at,deleted_at) VALUES (?,?,?,?,NULL,0,0,?,?,?,?,NULL)");
        $stmt->execute([$title,$slug,$content,$excerpt,$status,$pageDate,$pageDate,$status==='published'?$pageDate:null]);
        $pageId=(int)$pdo->lastInsertId();
        $pdo->prepare("INSERT INTO $linkTable (page_id,category_id) VALUES (?,?)")->execute([$pageId,$category]);
        $uidFingerprint=hash('sha256',$mailbox.'|'.$folder.'|'.$uidValidity.'|'.$uid); $messageIdHash=$msgId!==''?hash('sha256',$msgId):'';
        $stmt=$pdo->prepare('INSERT INTO '.etp_table().' (mailbox_key,folder_name,uid_validity,imap_uid,uid_fingerprint,message_id,message_id_hash,content_sha256,sender,subject,mail_date,page_id,imported_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)');
        $stmt->execute([$mailbox,$folder,$uidValidity,$uid,$uidFingerprint,$msgId,$messageIdHash,$hash,substr((string)$mail['from'],0,255),$title,$pageDate,$pageId,$now]);
        $pdo->commit(); return $pageId;
    } catch(Throwable $e) {
        if($pdo->inTransaction()) $pdo->rollBack();
        foreach($contentFiles as $file) if(is_file($file)) @unlink($file);
        throw $e;
    }
}
function etp_admin_session_valid(): bool {
    global $pdo;
    if (empty($_SESSION['admin_id'])) return false;
    $q=$pdo->prepare('SELECT is_active FROM '.cms_table('admins').' WHERE id=? LIMIT 1'); $q->execute([(int)$_SESSION['admin_id']]);
    if((int)$q->fetchColumn()!==1){$_SESSION=[];if(session_status()===PHP_SESSION_ACTIVE)session_destroy();return false;}
    return true;
}
function etp_mobile_login(): ?string {
    global $pdo;
    if($_SERVER['REQUEST_METHOD']!=='POST' || (string)($_POST['etp_action']??'')!=='mobile_login') return null;
    csrf_check(); $ip=(string)($_SERVER['REMOTE_ADDR']??'unknown'); $ipHash=hash_hmac('sha256',$ip,etp_crypto_key());
    $attempts=$pdo->prepare('SELECT COUNT(*) FROM '.cms_table('email_login_attempts').' WHERE ip_hash=? AND attempted_at>=?');
    $attempts->execute([$ipHash,date('Y-m-d H:i:s',time()-900)]);
    if((int)$attempts->fetchColumn()>=5) return 'Troppi tentativi di accesso. Riprova tra 15 minuti.';
    $user=trim((string)($_POST['username']??''));
    $q=$pdo->prepare('SELECT id,username,password_hash,role,display_name,is_active FROM '.cms_table('admins').' WHERE username=? LIMIT 1'); $q->execute([$user]); $a=$q->fetch();
    if($a && (int)$a['is_active']===1 && password_verify((string)($_POST['password']??''),(string)$a['password_hash'])) {
        $pdo->prepare('DELETE FROM '.cms_table('email_login_attempts').' WHERE ip_hash=?')->execute([$ipHash]);
        session_regenerate_id(true); $_SESSION['admin_id']=(int)$a['id']; $_SESSION['admin_username']=$a['username']; $_SESSION['admin_role']=$a['role']; $_SESSION['admin_display_name']=$a['display_name']??''; $_SESSION['etp_mobile_last_activity']=time(); return null;
    }
    $pdo->prepare('INSERT INTO '.cms_table('email_login_attempts').' (ip_hash,attempted_at) VALUES (?,?)')->execute([$ipHash,date('Y-m-d H:i:s')]);
    return 'Credenziali amministrative non valide.';
}
function etp_mobile_session_valid(): bool {
    if(!etp_admin_session_valid()) return false;
    $now=time(); $last=(int)($_SESSION['etp_mobile_last_activity']??0);
    if($last>0 && $now-$last>1800) { unset($_SESSION['admin_id'],$_SESSION['admin_username'],$_SESSION['admin_role'],$_SESSION['admin_display_name'],$_SESSION['etp_mobile_last_activity']); return false; }
    $_SESSION['etp_mobile_last_activity']=$now; return true;
}
function etp_secure_transport(): bool {
    $https=(!empty($_SERVER['HTTPS'])&&strtolower((string)$_SERVER['HTTPS'])!=='off') || strtolower((string)($_SERVER['REQUEST_SCHEME']??''))==='https';
    $host=strtolower((string)($_SERVER['HTTP_HOST']??'')); $host=preg_replace('/:[0-9]+$/','',$host)??$host;
    return $https || in_array($host,['localhost','127.0.0.1','::1','[::1]'],true);
}
function etp_mobile_url(string $token): string {
    if(!etp_secure_transport()) return '';
    $script=str_replace('\\','/',(string)($_SERVER['SCRIPT_NAME']??''));
    $base=preg_replace('~/plugins/email-to-page/admin\.php$~','',$script);
    if(!is_string($base)||$base===$script) $base='';
    $host=(string)($_SERVER['HTTP_HOST']??'');
    if(!preg_match('/^(?:[A-Za-z0-9.-]+|\[[0-9A-Fa-f:]+\])(?::[0-9]{1,5})?$/D',$host)) return '';
    $https=(!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off');
    return ($https?'https':'http').'://'.$host.$base.'/plugins/email-to-page/phone.php?k='.rawurlencode($token);
}
function etp_import_selected(array $c, array $uids): array {
    $available=[]; foreach(etp_list_messages($c) as $row) $available[$row['uid']]=$row;
    $results=[];
    foreach(array_values(array_unique(array_map('strval',$uids))) as $uid) {
        if(!preg_match('/^[0-9]{1,20}$/',$uid) || !isset($available[$uid])) { $results[]=['uid'=>$uid,'ok'=>false,'message'=>'Messaggio non disponibile o già importato.']; continue; }
        try {
            $fetched=etp_fetch_message($c,$uid); $mail=$fetched['mail'];
            if(!etp_allowed_sender($c,(string)$mail['from'])) throw new RuntimeException('Mittente non autorizzato.');
            $pageId=etp_create_page($c,$uid,(string)$fetched['uid_validity'],$mail);
            $results[]=['uid'=>$uid,'ok'=>true,'page_id'=>$pageId,'subject'=>$mail['subject']];
        } catch(Throwable $e) { $results[]=['uid'=>$uid,'ok'=>false,'message'=>$e->getMessage()]; }
    }
    return $results;
}
