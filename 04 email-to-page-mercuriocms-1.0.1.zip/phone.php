<?php
require_once dirname(__DIR__, 2) . '/app/bootstrap.php';
require_once __DIR__ . '/lib.php';
if(!etp_is_active()) { http_response_code(404); exit('Estensione non attiva.'); }
etp_ensure_schema();
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('X-Robots-Tag: noindex, nofollow, noarchive');
header('Referrer-Policy: no-referrer');
header('X-Frame-Options: DENY');
header('X-Content-Type-Options: nosniff');
if(!etp_secure_transport()) { http_response_code(403); exit('Per accedere alla posta riservata è necessaria una connessione HTTPS.'); }
$c=etp_config(); $token=(string)($_GET['k']??'');
if($token==='' || $c['secret_hash']==='' || !hash_equals((string)$c['secret_hash'],hash('sha256',$token))) { http_response_code(404); exit('Pagina non trovata.'); }
$errors=[]; $notice='';
$loginError=etp_mobile_login(); if($loginError!==null)$errors[]=$loginError;
if(etp_mobile_session_valid() && $_SERVER['REQUEST_METHOD']==='POST' && (string)($_POST['etp_action']??'')==='import') {
    csrf_check(); $selected=$_POST['uids']??[]; if(!is_array($selected))$selected=[];
    $category=(int)($_POST['category_id']??$c['category_id']);
    $cat=$pdo->prepare('SELECT id FROM '.cms_table('categories').' WHERE id=?');$cat->execute([$category]);
    if($cat->fetchColumn())$c['category_id']=$category; else $errors[]='Categoria non valida.';
    if(!$errors) {
        try { $results=etp_import_selected($c,$selected); foreach($results as $r) { if($r['ok'])$notice.='Pagina creata: '.$r['subject'].' (#'.$r['page_id'].'). ';else $errors[]='Messaggio '.$r['uid'].': '.$r['message']; } }
        catch(Throwable $e){$errors[]=$e->getMessage();}
    }
}
$messages=[];$connectionError='';$preview=null;
if(etp_mobile_session_valid() && $c['host']!=='' && $c['password_enc']!=='') {
    try{$messages=etp_list_messages($c);}catch(Throwable $e){$connectionError=$e->getMessage();}
    if(isset($_GET['preview'])&&preg_match('/^[0-9]{1,20}$/',(string)$_GET['preview'])) { try{$preview=etp_fetch_message($c,(string)$_GET['preview'])['mail'];}catch(Throwable $e){$errors[]=$e->getMessage();} }
}
$categories=$pdo->query('SELECT id,name FROM '.cms_table('categories').' ORDER BY sort_order,name')->fetchAll();
$script=str_replace('\\','/',(string)($_SERVER['SCRIPT_NAME']??''));$base=preg_replace('~/plugins/email-to-page/phone\.php$~','',$script);if(!is_string($base)||$base===$script)$base='';
?><!doctype html><html lang="it"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1"><meta name="robots" content="noindex,nofollow,noarchive"><meta name="referrer" content="no-referrer"><title>Posta riservata - MercurioCMS</title><link rel="stylesheet" href="<?=etp_h($base)?>/assets/css/admin.css"><style>
*{box-sizing:border-box}body{background:#f3f5f8;margin:0;color:#1d2733;font-family:Arial,sans-serif}.etp-phone{max-width:760px;margin:0 auto;padding:18px 14px 40px}.etp-head{background:#fff;border:1px solid #dce3ea;border-radius:14px;padding:18px;margin-bottom:14px}.etp-head h1{font-size:23px;margin:0 0 5px}.etp-card{background:#fff;border:1px solid #dce3ea;border-radius:12px;padding:15px;margin:12px 0}.etp-card h2{font-size:18px;margin:0 0 12px}.etp-field{display:block;margin:12px 0 5px;font-weight:600}.etp-phone input[type=text],.etp-phone input[type=password],.etp-phone input[type=number],.etp-phone select{width:100%;padding:12px;border:1px solid #cbd5df;border-radius:8px;font-size:16px;background:#fff}.etp-phone button{width:100%;padding:13px 14px;border:0;border-radius:8px;background:#244735;color:#fff;font-size:16px;font-weight:700;margin-top:10px}.etp-phone button.secondary{background:#e8edf2;color:#253342}.etp-mail{border:1px solid #e1e7ed;border-radius:10px;padding:12px;margin:10px 0}.etp-mail-top{display:flex;gap:10px;align-items:flex-start}.etp-mail input{width:22px;height:22px;flex:none;margin:1px 0 0}.etp-mail strong{display:block;line-height:1.35}.etp-meta{font-size:13px;color:#657386;margin-top:5px;overflow-wrap:anywhere}.etp-mail a{display:inline-block;margin-top:9px}.etp-help{color:#667487;font-size:14px;line-height:1.5}.etp-error{background:#fff0f0;border:1px solid #efbcbc;padding:12px;border-radius:9px}.etp-notice{background:#edf8ef;border:1px solid #b9dfc1;padding:12px;border-radius:9px}.etp-preview{overflow-wrap:anywhere}.etp-preview img{max-width:100%;height:auto}.etp-actions{display:flex;gap:8px;flex-wrap:wrap}.etp-actions a{color:#244735}
</style></head><body><main class="etp-phone"><header class="etp-head"><h1>MercurioCMS</h1><div class="etp-help">Gestione riservata della posta e pubblicazione delle pagine</div></header>
<?php if($notice):?><div class="etp-notice"><?=etp_h($notice)?></div><?php endif;?><?php if($errors):?><div class="etp-error"><ul><?php foreach($errors as $err):?><li><?=etp_h($err)?></li><?php endforeach;?></ul></div><?php endif;?>
<?php if(!etp_mobile_session_valid()):?><section class="etp-card"><h2>Accesso amministratore</h2><p class="etp-help">Per visualizzare la casella e i messaggi devi autenticarti con le credenziali di un amministratore MercurioCMS.</p><form method="post"><input type="hidden" name="csrf" value="<?=etp_h(etp_csrf())?>"><input type="hidden" name="etp_action" value="mobile_login"><label class="etp-field">Nome utente</label><input type="text" name="username" autocomplete="username" required><label class="etp-field">Password</label><input type="password" name="password" autocomplete="current-password" required><button type="submit">Accedi</button></form></section>
<?php else:?><section class="etp-card"><div class="etp-actions" style="justify-content:space-between;align-items:center"><strong>Benvenuto, <?=etp_h((string)(($_SESSION['admin_display_name']??'')?:($_SESSION['admin_username']??'amministratore')))?></strong><a href="<?=$base?>/admin/dashboard.php">Dashboard CMS</a></div><p class="etp-help">Seleziona le e-mail che vuoi trasformare in pagine. I messaggi già importati non vengono riproposti.</p></section>
<?php if($connectionError):?><section class="etp-card"><div class="etp-error">Connessione IMAP non disponibile: <?=etp_h($connectionError)?></div></section><?php elseif(!$messages):?><section class="etp-card"><p>Nessun nuovo messaggio da importare.</p></section><?php else:?><form method="post"><input type="hidden" name="csrf" value="<?=etp_h(etp_csrf())?>"><input type="hidden" name="etp_action" value="import"><section class="etp-card"><h2>Nuovi messaggi (<?=count($messages)?>)</h2><?php foreach($messages as $m):?><article class="etp-mail"><div class="etp-mail-top"><input type="checkbox" name="uids[]" value="<?=etp_h($m['uid'])?>"><div><strong><?=etp_h($m['subject'])?></strong><div class="etp-meta"><?=etp_h($m['from'])?><br><?=etp_h($m['date'])?></div><a href="?k=<?=rawurlencode($token)?>&amp;preview=<?=rawurlencode($m['uid'])?>">Apri anteprima</a></div></div></article><?php endforeach;?><label class="etp-field">Categoria delle pagine</label><select name="category_id"><?php foreach($categories as $cat):?><option value="<?=(int)$cat['id']?>" <?=(int)$c['category_id']===(int)$cat['id']?'selected':''?>><?=etp_h($cat['name'])?></option><?php endforeach;?></select><p class="etp-help">Stato iniziale: <?=$c['page_status']==='published'?'pubblicata':'bozza'?>. Puoi modificarlo nella dashboard.</p><button type="submit">Crea pagine selezionate</button></section></form><?php endif;?>
<?php if($preview):?><section class="etp-card"><h2>Anteprima e-mail</h2><p><strong><?=etp_h($preview['subject'])?></strong><br><span class="etp-meta"><?=etp_h($preview['from'])?> · <?=etp_h($preview['date'])?></span></p><div class="etp-preview"><?=etp_preview_html($preview)?></div><p class="etp-help">Immagini riconosciute: <?=count($preview['images'])?>.</p><a href="?k=<?=rawurlencode($token)?>">Torna all'elenco</a></section><?php endif;?>
<form method="post" action="<?=$base?>/admin/logout.php"><input type="hidden" name="csrf" value="<?=etp_h(etp_csrf())?>"><button type="submit" class="secondary">Esci da MercurioCMS</button></form>
<?php endif;?></main></body></html>
