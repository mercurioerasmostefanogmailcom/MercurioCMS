<?php
require_once dirname(__DIR__, 2) . '/app/bootstrap.php';
require_admin();
require_once __DIR__ . '/lib.php';
if(!etp_is_active()) { http_response_code(404); exit('Estensione non attiva.'); }
if(!etp_secure_transport()) { http_response_code(403); exit('Per gestire la posta è necessaria una connessione HTTPS. In locale è consentito localhost.'); }
etp_ensure_schema();
$c=etp_config(); $errors=[]; $notice=''; $tokenUrl=(string)($_SESSION['etp_new_mobile_url']??''); unset($_SESSION['etp_new_mobile_url']);
function etp_config_from_post(array $old): array {
    $c=$old; $c['host']=trim((string)($_POST['host']??'')); $c['port']=(int)($_POST['port']??993);
    $c['security']=(string)($_POST['security']??'ssl'); $c['username']=trim((string)($_POST['username']??''));
    $c['folder']=trim((string)($_POST['folder']??'INBOX')); $c['timeout']=(int)($_POST['timeout']??20);
    $c['allowed_senders']=trim((string)($_POST['allowed_senders']??'')); $c['max_messages']=(int)($_POST['max_messages']??30);
    $c['category_id']=(int)($_POST['category_id']??0); $c['page_status']=(string)($_POST['page_status']??'draft');
    $password=(string)($_POST['password']??''); if($password!=='') $c['password_enc']=etp_encrypt_password($password);
    if(!in_array($c['security'],['ssl','starttls'],true)) $c['security']='ssl';
    if($c['port']<1||$c['port']>65535) $c['port']=$c['security']==='ssl'?993:143;
    if($c['timeout']<5||$c['timeout']>60) $c['timeout']=20;
    if($c['max_messages']<1||$c['max_messages']>100) $c['max_messages']=30;
    if(!in_array($c['page_status'],['draft','published'],true)) $c['page_status']='draft';
    return $c;
}
if($_SERVER['REQUEST_METHOD']==='POST') {
    csrf_check(); $action=(string)($_POST['action']??'');
    if($action==='save' || $action==='test') {
        try {
            $new=etp_config_from_post($c);
            if($new['host']===''||$new['username']===''||$new['password_enc']==='') throw new RuntimeException('Compila server, nome utente e password della casella IMAP.');
            if(!preg_match('/^[A-Za-z0-9.-]+$/',$new['host'])) throw new RuntimeException('Nome server non valido.');
            if($new['folder']===''||strlen($new['folder'])>190) throw new RuntimeException('Nome cartella IMAP non valido.');
            $cat=$pdo->prepare('SELECT id FROM '.cms_table('categories').' WHERE id=?'); $cat->execute([$new['category_id']]);
            if(!$cat->fetchColumn()) throw new RuntimeException('Seleziona una categoria esistente di MercurioCMS.');
            if($action==='test') { $client=etp_connect($new); $client->close(); $notice='Connessione IMAP riuscita. Server, credenziali e cartella sono corretti.'; }
            else { etp_save_config($new); $c=$new; $notice='Impostazioni salvate correttamente.'; }
        } catch(Throwable $e) { $errors[]=$e->getMessage(); }
    } elseif($action==='generate_secret') {
        if(!etp_secure_transport()) $errors[]='Per creare il collegamento da smartphone è necessario usare MercurioCMS tramite HTTPS. In locale è consentito localhost.';
        elseif($c['host']==='' || $c['username']==='' || $c['password_enc']==='') $errors[]='Configura prima la casella IMAP e salva le impostazioni.';
        else { $token=bin2hex(random_bytes(32)); $c['secret_hash']=hash('sha256',$token); etp_save_config($c); $_SESSION['etp_new_mobile_url']=etp_mobile_url($token); header('Location: admin.php?secret=created'); exit; }
    } elseif($action==='import') {
        $selected=$_POST['uids']??[]; if(!is_array($selected))$selected=[];
        $override=(int)($_POST['import_category']??$c['category_id']);
        $cat=$pdo->prepare('SELECT id FROM '.cms_table('categories').' WHERE id=?');$cat->execute([$override]);
        if($cat->fetchColumn())$c['category_id']=$override;
        try { $results=etp_import_selected($c,$selected); foreach($results as $r) { if($r['ok']) $notice.='Pagina creata: '.$r['subject'].' (ID '.$r['page_id'].'). '; else $errors[]='Messaggio '.$r['uid'].': '.$r['message']; } }
        catch(Throwable $e){$errors[]=$e->getMessage();}
    }
}
if(isset($_GET['secret'])&&$_GET['secret']==='created') $notice='Nuovo collegamento riservato generato. Copialo e conservalo sul telefono: per sicurezza non verrà mostrato nuovamente.';
$categories=$pdo->query('SELECT id,name FROM '.cms_table('categories').' ORDER BY sort_order,name')->fetchAll();
$messages=[]; $connectionError='';
if($c['host']!==''&&$c['username']!==''&&$c['password_enc']!=='') { try{$messages=etp_list_messages($c);}catch(Throwable $e){$connectionError=$e->getMessage();} }
$history=$pdo->prepare('SELECT id,subject,sender,mail_date,page_id,imported_at FROM '.etp_table().' WHERE mailbox_key=? ORDER BY imported_at DESC LIMIT 50');$history->execute([etp_mailbox_key($c)]);$historyRows=$history->fetchAll();
$preview=null; if(isset($_GET['preview'])&&preg_match('/^[0-9]{1,20}$/',(string)$_GET['preview'])) { try{$preview=etp_fetch_message($c,(string)$_GET['preview'])['mail'];}catch(Throwable $e){$errors[]=$e->getMessage();} }
$script=str_replace('\\','/',(string)($_SERVER['SCRIPT_NAME']??''));$base=preg_replace('~/plugins/email-to-page/admin\.php$~','',$script);if(!is_string($base)||$base===$script)$base='';
?><!doctype html><html lang="it"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow,noarchive"><title>Pubblicazione via e-mail - MercurioCMS</title><link rel="stylesheet" href="<?=etp_h($base)?>/assets/css/admin.css"><style>
.etp-wrap{max-width:1150px}.etp-help{color:#596579;line-height:1.55}.etp-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:14px}.etp-form label{display:block;font-weight:600;margin:12px 0 5px}.etp-form input,.etp-form select,.etp-form textarea{width:100%;box-sizing:border-box;padding:10px;border:1px solid #cbd5df;border-radius:7px}.etp-table{width:100%;border-collapse:collapse}.etp-table th,.etp-table td{text-align:left;padding:10px 8px;border-bottom:1px solid #e2e8f0;vertical-align:top}.etp-table th{white-space:nowrap}.etp-actions{display:flex;gap:8px;flex-wrap:wrap}.etp-actions button,.etp-actions a{font:inherit}.etp-secret{overflow-wrap:anywhere;padding:12px;background:#eef6ff;border:1px solid #b7d5f5;border-radius:8px}.etp-preview{padding:14px;border:1px solid #dce3ea;border-radius:8px;overflow-wrap:anywhere}.etp-preview img{max-width:100%;height:auto}.etp-mobile{display:none}@media(max-width:650px){.etp-desktop{display:none}.etp-mobile{display:block}.etp-table thead{display:none}.etp-table tr{display:block;border:1px solid #e2e8f0;border-radius:9px;padding:8px;margin:10px 0}.etp-table td{display:block;border:0;padding:5px}.etp-table td:first-child{font-weight:700}}
</style><script>
function etpCopyMobileLink(button) {
    var url = button.getAttribute('data-copy-url') || '';
    var feedback = button.parentElement.querySelector('.etp-copy-feedback');
    function report(ok) {
        if (feedback) feedback.textContent = ok
            ? 'Collegamento copiato. Ora puoi incollarlo sul telefono.'
            : 'Copia automatica non disponibile: seleziona e copia il collegamento mostrato sopra.';
    }
    function fallbackCopy() {
        var field = document.createElement('textarea');
        field.value = url;
        field.setAttribute('readonly', '');
        field.style.position = 'fixed';
        field.style.left = '-9999px';
        field.style.top = '0';
        document.body.appendChild(field);
        field.focus();
        field.select();
        field.setSelectionRange(0, field.value.length);
        var copied = false;
        try { copied = document.execCommand('copy'); } catch (e) { copied = false; }
        document.body.removeChild(field);
        report(copied);
    }
    if (navigator.clipboard && window.isSecureContext && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(url).then(function () { report(true); }).catch(fallbackCopy);
    } else {
        fallbackCopy();
    }
}
</script></head><body><?php
$adminActive='plugins';
$adminSidebarPath=dirname(__DIR__,2).'/admin/_sidebar.php';
$adminBasePath=rtrim($base,'/').'/admin/';
ob_start();
require $adminSidebarPath;
$adminSidebar=(string)ob_get_clean();
$adminSidebar=preg_replace_callback('/(\bhref\s*=\s*)([\"\'])(.*?)\2/i', function($m) use ($adminBasePath) {
    $href=html_entity_decode($m[3], ENT_QUOTES, 'UTF-8');
    if ($href==='' || preg_match('~^(?:[a-z][a-z0-9+.-]*:|//|/|#|\?)~i', $href)) return $m[0];
    $parts=parse_url($href);
    $path=(string)($parts['path']??'');
    if ($path==='') return $m[0];
    $segments=[];
    foreach (explode('/', rtrim($adminBasePath,'/').'/'.$path) as $segment) {
        if ($segment==='' || $segment==='.') continue;
        if ($segment==='..') { array_pop($segments); continue; }
        $segments[]=$segment;
    }
    $resolved='/'.implode('/',$segments);
    if (isset($parts['query'])) $resolved.='?'.$parts['query'];
    if (isset($parts['fragment'])) $resolved.='#'.$parts['fragment'];
    return $m[1].$m[2].htmlspecialchars($resolved, ENT_QUOTES, 'UTF-8').$m[2];
}, $adminSidebar) ?? $adminSidebar;
echo $adminSidebar;
?><main class="container etp-wrap"><h1>Pubblicazione via e-mail</h1><p class="etp-help">Collega una casella IMAP, scegli i messaggi e trasformali in pagine MercurioCMS. La stessa funzione è disponibile da smartphone tramite un collegamento riservato e autenticazione amministrativa.</p>
<?php if($notice):?><p class="notice"><?=etp_h($notice)?></p><?php endif;?><?php if($errors):?><div class="error"><ul><?php foreach($errors as $e):?><li><?=etp_h($e)?></li><?php endforeach;?></ul></div><?php endif;?>
<section class="panel etp-form"><h2>1. Configurazione casella IMAP</h2><form method="post"><input type="hidden" name="csrf" value="<?=etp_h(etp_csrf())?>"><input type="hidden" name="action" value="save"><div class="etp-grid"><div><label>Server IMAP</label><input name="host" value="<?=etp_h((string)$c['host'])?>" placeholder="imap.esempio.it" required></div><div><label>Porta</label><input name="port" type="number" min="1" max="65535" value="<?=(int)$c['port']?>" required></div><div><label>Sicurezza connessione</label><select name="security"><option value="ssl" <?=$c['security']==='ssl'?'selected':''?>>SSL/TLS (consigliato, porta 993)</option><option value="starttls" <?=$c['security']==='starttls'?'selected':''?>>STARTTLS (normalmente porta 143)</option></select></div><div><label>Cartella IMAP</label><input name="folder" value="<?=etp_h((string)$c['folder'])?>" required></div><div><label>Nome utente / indirizzo e-mail</label><input name="username" value="<?=etp_h((string)$c['username'])?>" autocomplete="username" required></div><div><label>Password</label><input name="password" type="password" autocomplete="new-password" placeholder="<?= $c['password_enc']!==''?'Lascia vuoto per mantenere quella salvata':'Inserisci la password' ?>"></div><div><label>Timeout (secondi)</label><input name="timeout" type="number" min="5" max="60" value="<?=(int)$c['timeout']?>"></div><div><label>Numero massimo messaggi da mostrare</label><input name="max_messages" type="number" min="1" max="100" value="<?=(int)$c['max_messages']?>"></div></div><label>Mittenti autorizzati (facoltativo)</label><textarea name="allowed_senders" rows="2" placeholder="nome@dominio.it oppure @dominio.it"><?=etp_h((string)$c['allowed_senders'])?></textarea><p class="etp-help">Inserisci un indirizzo per riga. Se lasci vuoto, saranno mostrati tutti i mittenti. Puoi indicare anche un dominio, ad esempio @dominio.it.</p><div class="etp-grid"><div><label>Categoria predefinita</label><select name="category_id" required><option value="0">Seleziona categoria</option><?php foreach($categories as $cat):?><option value="<?=(int)$cat['id']?>" <?=(int)$c['category_id']===(int)$cat['id']?'selected':''?>><?=etp_h($cat['name'])?></option><?php endforeach;?></select></div><div><label>Stato iniziale delle pagine</label><select name="page_status"><option value="draft" <?=$c['page_status']==='draft'?'selected':''?>>Bozza (consigliato)</option><option value="published" <?=$c['page_status']==='published'?'selected':''?>>Pubblicata immediatamente</option></select></div></div><p class="etp-actions"><button type="submit">Salva impostazioni</button></p></form><form method="post" class="etp-actions"><input type="hidden" name="csrf" value="<?=etp_h(etp_csrf())?>"><input type="hidden" name="action" value="test"><?php foreach(['host','port','security','folder','username','timeout','max_messages','allowed_senders','category_id','page_status'] as $field):?><input type="hidden" name="<?=$field?>" value="<?=etp_h((string)$c[$field])?>"><?php endforeach;?><input type="hidden" name="password" value=""><button type="submit" class="secondary">Verifica connessione salvata</button></form></section>
<section class="panel"><h2>2. Accesso da smartphone</h2><p class="etp-help">Il collegamento segreto è un ulteriore controllo, ma non sostituisce l'accesso con nome utente e password amministratore. Nessun messaggio viene letto o mostrato prima dell'autenticazione.</p><?php if($tokenUrl!==''):?><div class="etp-secret"><strong>Collegamento da copiare sul telefono</strong><p><?=etp_h($tokenUrl)?></p><button type="button" class="etp-copy-link" data-copy-url="<?=etp_h($tokenUrl)?>" onclick="etpCopyMobileLink(this)">Copia collegamento</button><span class="etp-copy-feedback" role="status" aria-live="polite" style="display:block;margin-top:7px"></span></div><?php else:?><p class="etp-help">Per creare o sostituire il collegamento riservato, premi il pulsante. Il collegamento precedente verrà invalidato.</p><?php endif;?><form method="post" onsubmit="return confirm('Generare un nuovo collegamento? Quello precedente smetterà di funzionare.');"><input type="hidden" name="csrf" value="<?=etp_h(etp_csrf())?>"><input type="hidden" name="action" value="generate_secret"><button type="submit" class="secondary">Genera / rinnova collegamento segreto</button></form></section>
<section class="panel"><h2>3. Messaggi disponibili<?php if($messages):?> (<?=count($messages)?>)<?php endif;?></h2><?php if($connectionError):?><p class="error">Connessione non disponibile: <?=etp_h($connectionError)?></p><?php elseif(!$c['host']||!$c['password_enc']):?><p>Configura prima la casella IMAP.</p><?php elseif(!$messages):?><p>Nessun nuovo messaggio da importare.</p><?php else:?><form method="post"><input type="hidden" name="csrf" value="<?=etp_h(etp_csrf())?>"><input type="hidden" name="action" value="import"><div class="table-wrap"><table class="etp-table"><thead><tr><th></th><th>Oggetto</th><th>Mittente</th><th>Data</th><th></th></tr></thead><tbody><?php foreach($messages as $m):?><tr><td><input type="checkbox" name="uids[]" value="<?=etp_h($m['uid'])?>"></td><td><strong><?=etp_h($m['subject'])?></strong></td><td><?=etp_h($m['from'])?></td><td><?=etp_h($m['date'])?></td><td><a href="?preview=<?=rawurlencode($m['uid'])?>">Anteprima</a></td></tr><?php endforeach;?></tbody></table></div><div class="etp-grid"><div><label>Categoria per questa importazione</label><select name="import_category"><?php foreach($categories as $cat):?><option value="<?=(int)$cat['id']?>" <?=(int)$c['category_id']===(int)$cat['id']?'selected':''?>><?=etp_h($cat['name'])?></option><?php endforeach;?></select></div><div style="align-self:end"><button type="submit">Crea pagine dai messaggi selezionati</button></div></div></form><?php endif;?></section>
<?php if($preview):?><section class="panel"><h2>Anteprima messaggio</h2><p><strong><?=etp_h($preview['subject'])?></strong><br><?=etp_h($preview['from'])?> · <?=etp_h($preview['date'])?></p><div class="etp-preview"><?=etp_preview_html($preview)?></div><?php if($preview['images']):?><p class="etp-help">Immagini riconosciute: <?=count($preview['images'])?>.</p><?php endif;?><p><a href="admin.php">Torna ai messaggi</a></p></section><?php endif;?>
<section class="panel"><h2>4. Messaggi già importati</h2><?php if(!$historyRows):?><p>Non sono ancora state create pagine da e-mail.</p><?php else:?><div class="table-wrap"><table class="etp-table"><thead><tr><th>Oggetto</th><th>Mittente</th><th>Ricevuta</th><th>Pagina</th><th>Importata</th></tr></thead><tbody><?php foreach($historyRows as $h):?><tr><td><?=etp_h($h['subject'])?></td><td><?=etp_h($h['sender'])?></td><td><?=etp_h((string)$h['mail_date'])?></td><td><?php if($h['page_id']):?><a href="<?=$base?>/admin/pages.php?edit=<?=(int)$h['page_id']?>">Apri pagina #<?=(int)$h['page_id']?></a><?php else:?>—<?php endif;?></td><td><?=etp_h($h['imported_at'])?></td></tr><?php endforeach;?></tbody></table></div><?php endif;?></section>
</main></div></div></body></html>
