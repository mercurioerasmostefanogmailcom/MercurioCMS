<?php
require_once __DIR__ . '/../../app/bootstrap.php';
require_admin();

$errors = [];
$flash = $_SESSION['google_forms_flash'] ?? '';
unset($_SESSION['google_forms_flash']);
$currentUrl = cms_setting('google_forms_embed_url', '');
$currentHeight = cms_setting('google_forms_height', '1200');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $urlInput = trim((string)($_POST['google_forms_url'] ?? ''));
    $heightInput = trim((string)($_POST['google_forms_height'] ?? '1200'));
    $normalized = cms_google_forms_normalize_url($urlInput);

    if ($urlInput !== '' && $normalized === '') {
        $errors[] = 'Indirizzo non valido. Usa il link di visualizzazione Google Forms su docs.google.com, che termina con /viewform.';
    }
    if (!preg_match('/^[0-9]{3,4}$/', $heightInput) || (int)$heightInput < 400 || (int)$heightInput > 6000) {
        $errors[] = 'L’altezza deve essere un numero compreso tra 400 e 6000 pixel.';
    }

    if (!$errors) {
        cms_set_setting('google_forms_embed_url', $normalized);
        cms_set_setting('google_forms_height', (string)(int)$heightInput);
        $_SESSION['google_forms_flash'] = 'Impostazioni Google Forms salvate.';
        header('Location: admin.php');
        exit;
    }

    $currentUrl = $urlInput;
    $currentHeight = $heightInput;
}
?>
<!doctype html>
<html lang="it">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<base href="../../admin/">
<title>Google Forms - MercurioCMS</title>
<link rel="stylesheet" href="../assets/css/admin.css">
<style>
.gf-code{display:block;padding:12px;border:1px solid #d8dee5;border-radius:8px;background:#f5f7f9;color:#18212b;font-family:monospace;overflow-wrap:anywhere}
.gf-help{color:#52606d;line-height:1.55}.gf-form{max-width:850px}.gf-form input[type=url],.gf-form input[type=number]{width:100%;max-width:100%;box-sizing:border-box;padding:10px;border:1px solid #cbd5df;border-radius:6px}.gf-form label{display:block;margin:14px 0 6px;font-weight:600}
</style>
</head>
<body>
<?php $adminActive = 'plugins'; require dirname(__DIR__, 2) . '/admin/_sidebar.php'; ?>
<main class="container gf-form">
<h1>Google Forms</h1>
<p class="gf-help">Configura il modulo da visualizzare nelle pagine pubbliche. L’estensione non modifica i file originali di MercurioCMS e non richiede di incollare codice iframe.</p>
<?php if ($flash): ?><p class="notice"><?= e($flash) ?></p><?php endif; ?>
<?php if ($errors): ?><div class="error"><ul><?php foreach ($errors as $error): ?><li><?= e($error) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
<section class="panel">
<h2>Impostazioni del modulo</h2>
<form method="post">
<input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
<label for="google_forms_url">Indirizzo del modulo Google Forms</label>
<input id="google_forms_url" type="url" name="google_forms_url" value="<?= e($currentUrl) ?>" placeholder="https://docs.google.com/forms/d/e/.../viewform" autocomplete="url">
<p class="gf-help">Incolla il normale link del modulo oppure l’indirizzo presente nell’attributo <code>src</code> del codice di incorporamento Google. Sono accettati esclusivamente moduli ospitati su docs.google.com.</p>
<label for="google_forms_height">Altezza del modulo (pixel)</label>
<input id="google_forms_height" type="number" name="google_forms_height" min="400" max="6000" step="50" value="<?= e($currentHeight) ?>" required>
<p class="gf-help">Puoi usare, ad esempio, 4140 pixel per il modulo di adesione di Viaggi Itineranti. L’altezza può essere modificata in seguito.</p>
<p><button type="submit">Salva impostazioni</button></p>
</form>
</section>
<section class="panel">
<h2>Inserire il modulo in una pagina</h2>
<ol>
<li>Salva qui sopra l’indirizzo Google Forms e l’altezza desiderata.</li>
<li>Apri la pagina in cui vuoi mostrare il modulo.</li>
<li>Nell’editor HTML inserisci, nel punto desiderato, questo segnaposto testuale:</li>
</ol>
<code class="gf-code">[[MERCURIO_GOOGLE_FORMS]]</code>
<p class="gf-help">Il segnaposto è testo semplice: il filtro di sicurezza di MercurioCMS lo conserva. Solo nella pagina pubblica l’estensione lo sostituisce con l’iframe generato. Non incollare il tag iframe nell’editor: il CMS continuerà correttamente a rimuoverlo.</p>
<p class="gf-help">È mantenuta anche la compatibilità con il vecchio segnaposto <code>&lt;span id="mercurio-google-form"&gt;&lt;/span&gt;</code>.</p>
</section>
<section class="panel">
<h2>Note</h2>
<ul>
<li>È possibile configurare un modulo alla volta; il segnaposto può essere inserito in una o più pagine.</li>
<li>Il modulo viene caricato direttamente da Google ed è soggetto alle impostazioni di condivisione e alle condizioni di Google Forms.</li>
<li>La visualizzazione è larga quanto il contenitore della pagina e si adatta agli schermi più piccoli.</li>
<li>La disattivazione interrompe l’incorporamento senza cancellare il testo segnaposto dalle pagine.</li>
</ul>
<p><a href="plugins.php">Torna a Gestione estensioni</a></p>
</section>
</main>
</body>
</html>
