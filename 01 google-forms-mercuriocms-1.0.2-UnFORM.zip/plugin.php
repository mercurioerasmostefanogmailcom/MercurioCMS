<?php
/**
 * Google Forms per MercurioCMS 1.0.1.
 *
 * Il filtro HTML del CMS rimuove intenzionalmente gli iframe. Questa estensione
 * NON modifica il filtro: conserva nel contenuto un semplice segnaposto testuale
 * e lo sostituisce con un iframe solo nell'HTML finale del front-end pubblico.
 */

if (!function_exists('cms_google_forms_normalize_url')) {
    /** Accetta esclusivamente URL di visualizzazione Google Forms su docs.google.com. */
    function cms_google_forms_normalize_url(string $input): string
    {
        $input = trim($input);
        if ($input === '' || strlen($input) > 2048) {
            return '';
        }

        $parts = parse_url($input);
        if (!is_array($parts)) {
            return '';
        }

        if (strtolower((string)($parts['scheme'] ?? '')) !== 'https'
            || strtolower((string)($parts['host'] ?? '')) !== 'docs.google.com'
            || isset($parts['user']) || isset($parts['pass'])
            || isset($parts['port']) || isset($parts['fragment'])) {
            return '';
        }

        $path = (string)($parts['path'] ?? '');
        // Formati ordinari: /forms/d/e/ID/viewform e /forms/d/ID/viewform.
        if (!preg_match('~^/forms/d/(?:e/)?[A-Za-z0-9_-]+/viewform/?$~D', $path)) {
            return '';
        }

        // Non trasferire parametri esterni: per l'embed basta embedded=true.
        return 'https://docs.google.com' . rtrim($path, '/') . '?embedded=true';
    }
}

if (!function_exists('cms_google_forms_render_buffer')) {
    /** Sostituisce il segnaposto soltanto nella pagina HTML pubblica. */
    function cms_google_forms_render_buffer(string $html): string
    {
        $script = str_replace('\\', '/', (string)($_SERVER['SCRIPT_NAME'] ?? ''));
        if (basename($script) !== 'index.php' || stripos($html, '<html') === false) {
            return $html;
        }

        $hasTextMarker = strpos($html, '[[MERCURIO_GOOGLE_FORMS]]') !== false;
        $hasLegacyMarker = stripos($html, 'mercurio-google-form') !== false;
        if (!$hasTextMarker && !$hasLegacyMarker) {
            return $html;
        }

        $url = cms_google_forms_normalize_url(
            function_exists('cms_setting') ? cms_setting('google_forms_embed_url', '') : ''
        );

        // Se non è configurato un modulo, rimuove il segnaposto senza lasciare residui.
        if ($url === '') {
            $html = str_replace('[[MERCURIO_GOOGLE_FORMS]]', '', $html);
            return preg_replace(
                '~<span\b(?=[^>]*\bid=["\']mercurio-google-form["\'])[^>]*>\s*</span>~i',
                '',
                $html
            ) ?? $html;
        }

        $height = (int)(function_exists('cms_setting') ? cms_setting('google_forms_height', '1200') : 1200);
        if ($height < 400 || $height > 6000) {
            $height = 1200;
        }

        $safeUrl = htmlspecialchars($url, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        $iframe = '<iframe src="' . $safeUrl . '"'
            . ' title="Modulo Google Forms"'
            . ' width="100%" height="' . $height . '"'
            . ' style="display:block;width:100%;max-width:100%;height:' . $height . 'px;border:0;background:#fff"'
            . ' loading="lazy" referrerpolicy="strict-origin-when-cross-origin"'
            . ' allow="fullscreen">'
            . '</iframe>';

        // Segnaposto testuale consigliato: sopravvive al filtro HTML del CMS.
        $html = str_replace('[[MERCURIO_GOOGLE_FORMS]]', $iframe, $html);

        // Compatibilità con le pagine che usavano il segnaposto HTML della 1.0.0.
        return preg_replace(
            '~<span\b(?=[^>]*\bid=["\']mercurio-google-form["\'])[^>]*>\s*</span>~i',
            $iframe,
            $html
        ) ?? $html;
    }
}

if (function_exists('cms_register_admin_menu')) {
    cms_register_admin_menu('google-forms', 'Google Forms', '../plugins/google-forms/admin.php');
}

// Il buffer viene avviato solo nella richiesta del front-end pubblico.
$cmsGoogleFormsScript = str_replace('\\', '/', (string)($_SERVER['SCRIPT_NAME'] ?? ''));
if (basename($cmsGoogleFormsScript) === 'index.php' && !headers_sent()) {
    ob_start('cms_google_forms_render_buffer');
}
