<?php
declare(strict_types=1);

function urlp_root(): string { return dirname(__DIR__, 2); }
function urlp_table(): string { return cms_table('url_page_imports'); }
function urlp_setting_key(): string { return 'url_to_page_config'; }
function urlp_h(string $s): string { return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function urlp_csrf(): string { return csrf_token(); }
function urlp_is_active(): bool {
    global $pdo;
    if (!cms_table_exists('plugins')) return false;
    $q=$pdo->prepare('SELECT is_active FROM '.cms_table('plugins').' WHERE plugin_id=? LIMIT 1');
    $q->execute(['url-to-page']); return (int)$q->fetchColumn()===1;
}
function urlp_base_path(): string {
    $script=str_replace('\\','/',(string)($_SERVER['SCRIPT_NAME']??''));
    $suffix='/plugins/url-to-page/'; $pos=strrpos($script,$suffix);
    if($pos!==false) return rtrim(substr($script,0,$pos),'/');
    return '';
}
function urlp_admin_url(string $file='dashboard.php'): string { return urlp_base_path().'/admin/'.ltrim($file,'/'); }
function urlp_mobile_url(string $token): string {
    $host=trim((string)($_SERVER['HTTP_HOST']??''));
    if($host==='' || !preg_match('/^(?:[A-Za-z0-9.-]+|\[[0-9A-Fa-f:]+\])(?::[0-9]{1,5})?$/D',$host)) {
        $host=trim((string)($_SERVER['SERVER_NAME']??''));
    }
    if($host==='' || !preg_match('/^(?:[A-Za-z0-9.-]+|\[[0-9A-Fa-f:]+\])(?::[0-9]{1,5})?$/D',$host)) {
        throw new RuntimeException('Impossibile determinare il dominio del sito per creare il collegamento mobile.');
    }
    $https=(!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS'])!=='off') || strtolower((string)($_SERVER['REQUEST_SCHEME']??''))==='https';
    $scheme=$https?'https':'http';
    return $scheme.'://'.$host.urlp_base_path().'/plugins/url-to-page/phone.php?k='.rawurlencode($token);
}
function urlp_secure_transport(): bool {
    $https=(!empty($_SERVER['HTTPS'])&&strtolower((string)$_SERVER['HTTPS'])!=='off') || strtolower((string)($_SERVER['REQUEST_SCHEME']??''))==='https';
    $host=strtolower((string)($_SERVER['HTTP_HOST']??'')); $host=preg_replace('/:[0-9]+$/','',$host)??$host;
    return $https || in_array($host,['localhost','127.0.0.1','::1'],true);
}
function urlp_default_config(): array { return ['category_id'=>0,'page_status'=>'draft','secret_hash'=>'','max_html_bytes'=>5242880,'max_image_bytes'=>5242880]; }
function urlp_config(): array {
    $raw=cms_setting(urlp_setting_key(),''); $saved=is_string($raw)?json_decode($raw,true):null;
    return array_merge(urlp_default_config(),is_array($saved)?$saved:[]);
}
function urlp_save_config(array $c): void { cms_set_setting(urlp_setting_key(),json_encode($c,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)); }
function urlp_ensure_schema(): void {
    global $pdo;
    if(!cms_table_exists('url_page_imports')) $pdo->exec('CREATE TABLE '.urlp_table().' (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      url_hash CHAR(64) NOT NULL,
      source_url TEXT NOT NULL,
      final_url TEXT NOT NULL,
      title VARCHAR(220) NOT NULL DEFAULT \'\',
      page_id BIGINT UNSIGNED NULL,
      status VARCHAR(20) NOT NULL DEFAULT \'fetched\',
      note TEXT NULL,
      fetched_at DATETIME NOT NULL,
      imported_at DATETIME NULL,
      PRIMARY KEY(id), UNIQUE KEY uq_url_hash(url_hash), KEY idx_url_page(page_id), KEY idx_url_status(status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');
    if(!cms_table_exists('url_page_login_attempts')) $pdo->exec('CREATE TABLE '.cms_table('url_page_login_attempts').' (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, ip_hash CHAR(64) NOT NULL, attempted_at DATETIME NOT NULL,
      PRIMARY KEY(id), KEY idx_url_login_ip_time(ip_hash,attempted_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');
}
function urlp_normalize_url(string $input): string {
    $input=trim($input); if($input==='' || strlen($input)>2048 || preg_match('/[\x00-\x20\x7f]/',$input)) throw new RuntimeException('Inserisci un indirizzo Internet valido (massimo 2.048 caratteri, senza spazi o caratteri di controllo).');
    if(!preg_match('~^https?://~i',$input)) $input='https://'.$input;
    $p=parse_url($input);
    if(!is_array($p)||empty($p['scheme'])||empty($p['host'])) throw new RuntimeException('Indirizzo Internet non valido.');
    $scheme=strtolower($p['scheme']); if(!in_array($scheme,['http','https'],true)) throw new RuntimeException('Sono ammessi soltanto indirizzi HTTP e HTTPS.');
    if(isset($p['user'])||isset($p['pass'])) throw new RuntimeException('Gli indirizzi con credenziali incorporate non sono consentiti.');
    $host=strtolower(rtrim((string)$p['host'],'.')); if($host===''||preg_match('/[^a-z0-9.\-:\[\]]/i',$host)) throw new RuntimeException('Nome host non valido.');
    $port=(int)($p['port']??($scheme==='https'?443:80)); if(($scheme==='https'&&$port!==443)||($scheme==='http'&&$port!==80)) throw new RuntimeException('Per sicurezza sono consentite soltanto le porte web standard 80 e 443.');
    $path=(string)($p['path']??'/'); if($path==='')$path='/';
    return $scheme.'://'.$host.($port===($scheme==='https'?443:80)?'':':'.$port).$path.(isset($p['query'])?'?'.$p['query']:'');
}
function urlp_resolve_url(string $base,string $relative): string {
    $relative=trim(html_entity_decode($relative,ENT_QUOTES|ENT_HTML5,'UTF-8'));
    if($relative===''||str_starts_with($relative,'#')||preg_match('~^(?:javascript|data|mailto|tel):~i',$relative)) return '';
    if(preg_match('~^https?://~i',$relative)) return urlp_normalize_url($relative);
    $b=parse_url($base); if(!$b)return '';
    $origin=$b['scheme'].'://'.$b['host'].(isset($b['port'])?':'.$b['port']:'');
    if(str_starts_with($relative,'//')) return urlp_normalize_url($b['scheme'].':'.$relative);
    if(str_starts_with($relative,'?')) return urlp_normalize_url($origin.($b['path']??'/').$relative);
    if(str_starts_with($relative,'/')) return urlp_normalize_url($origin.$relative);
    $path=(string)($b['path']??'/'); $dir=substr($path,0,(int)strrpos($path,'/')+1);
    $joined=$dir.$relative; $parts=[];
    foreach(explode('/',(string)(parse_url($joined,PHP_URL_PATH)??'/')) as $part){ if($part==='.'||$part==='')continue; if($part==='..'){array_pop($parts);continue;} $parts[]=$part; }
    $norm='/'.implode('/',$parts); $query=parse_url($joined,PHP_URL_QUERY);
    return urlp_normalize_url($origin.$norm.($query!==null?'?'.$query:''));
}
function urlp_public_ipv4(string $ip): bool {
    if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) === false) return false;

    // Confronto binario per CIDR: evita overflow/cast da float su PHP Windows
    // quando 0xFFFFFFFF supera il massimo intero della piattaforma.
    $packed = @inet_pton($ip);
    if ($packed === false || strlen($packed) !== 4) return false;

    $blocked = [
        '0.0.0.0/8', '10.0.0.0/8', '100.64.0.0/10', '127.0.0.0/8',
        '169.254.0.0/16', '172.16.0.0/12', '192.0.0.0/24', '192.0.2.0/24',
        '192.88.99.0/24', '192.168.0.0/16', '198.18.0.0/15',
        '198.51.100.0/24', '203.0.113.0/24', '224.0.0.0/4', '240.0.0.0/4'
    ];

    foreach ($blocked as $cidr) {
        [$network, $prefix] = explode('/', $cidr, 2);
        $networkPacked = @inet_pton($network);
        if ($networkPacked === false) continue;
        $remaining = (int) $prefix;
        $matches = true;
        for ($i = 0; $i < 4; $i++) {
            $bits = max(0, min(8, $remaining));
            $mask = $bits === 0 ? 0 : ((0xFF << (8 - $bits)) & 0xFF);
            if ((ord($packed[$i]) & $mask) !== (ord($networkPacked[$i]) & $mask)) {
                $matches = false;
                break;
            }
            $remaining -= $bits;
        }
        if ($matches) return false;
    }

    return filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 | FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false;
}
function urlp_public_ip_for_host(string $host): string {
    if(filter_var($host,FILTER_VALIDATE_IP,FILTER_FLAG_IPV4)) { if(!urlp_public_ipv4($host)) throw new RuntimeException('Indirizzo di rete privata o riservata non consentito.'); return $host; }
    if(filter_var($host,FILTER_VALIDATE_IP,FILTER_FLAG_IPV6)) throw new RuntimeException('Gli indirizzi IPv6 letterali non sono supportati; usa il nome del sito.');
    if(!preg_match('/^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)(?:\.(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?))*$/i',$host)) throw new RuntimeException('Nome host non valido.');
    $ips=@gethostbynamel($host); if(!$ips) throw new RuntimeException('Il dominio non risulta raggiungibile o non ha un indirizzo IPv4.');
    foreach($ips as $ip) if(!urlp_public_ipv4($ip)) throw new RuntimeException('Il dominio risolve verso una rete privata o riservata: richiesta bloccata.');
    return $ips[0];
}
function urlp_read_exact($stream,int $length): string {
    $out=''; while(strlen($out)<$length&&!feof($stream)){ $part=fread($stream,min(8192,$length-strlen($out))); if(!is_string($part)||$part==='')break; $out.=$part; }
    if(strlen($out)!==$length) throw new RuntimeException('Risposta del sito incompleta.'); return $out;
}
function urlp_http_once(string $url,int $limit): array {
    $p=parse_url($url); $host=(string)$p['host']; $scheme=(string)$p['scheme']; $port=$scheme==='https'?443:80; $ip=urlp_public_ip_for_host($host);
    $ctx=stream_context_create(['ssl'=>['verify_peer'=>true,'verify_peer_name'=>true,'peer_name'=>$host,'SNI_enabled'=>true,'allow_self_signed'=>false]]);
    $target=($scheme==='https'?'tls':'tcp').'://'.$ip.':'.$port; $errno=0;$err='';
    $fp=@stream_socket_client($target,$errno,$err,15,STREAM_CLIENT_CONNECT,$ctx); if(!$fp) throw new RuntimeException('Connessione al sito non riuscita: '.$err.' ('.$errno.').');
    stream_set_timeout($fp,20);
    $path=(string)($p['path']??'/'); if($path==='')$path='/'; if(isset($p['query']))$path.='?'.$p['query'];
    $hostHeader=$host.($port===($scheme==='https'?443:80)?'':':'.$port);
    $request="GET $path HTTP/1.1\r\nHost: $hostHeader\r\nUser-Agent: MercurioCMS-URL-Importer/1.0 (+page import)\r\nAccept: text/html,application/xhtml+xml;q=0.9,*/*;q=0.1\r\nAccept-Encoding: identity\r\nConnection: close\r\n\r\n";
    if(fwrite($fp,$request)!==strlen($request)){fclose($fp);throw new RuntimeException('Invio richiesta HTTP non riuscito.');}
    $statusLine=fgets($fp); if(!is_string($statusLine)||!preg_match('~^HTTP/\d(?:\.\d)?\s+(\d{3})~',$statusLine,$m)){fclose($fp);throw new RuntimeException('Il sito ha restituito una risposta HTTP non valida.');}
    $status=(int)$m[1];$headers=[];$total=0;
    while(($line=fgets($fp))!==false){$total+=strlen($line);if($total>32768){fclose($fp);throw new RuntimeException('Intestazioni HTTP troppo grandi.');}if($line==="\r\n"||$line==="\n")break;$pos=strpos($line,':');if($pos!==false){$k=strtolower(trim(substr($line,0,$pos)));$headers[$k]=trim(substr($line,$pos+1));}}
    $encoding=strtolower(trim((string)($headers['content-encoding']??'identity')));if($encoding!==''&&$encoding!=='identity'){fclose($fp);throw new RuntimeException('Il sito usa una compressione HTTP non supportata.');}
    $body='';while(!feof($fp)){ $chunk=fread($fp,8192);if(!is_string($chunk)||$chunk==='')break;$body.=$chunk;if(strlen($body)>$limit){fclose($fp);throw new RuntimeException('La pagina supera il limite di dimensione consentito.');} }
    $meta=stream_get_meta_data($fp);fclose($fp);if(!empty($meta['timed_out']))throw new RuntimeException('Tempo massimo di lettura del sito superato.');
    if(str_contains(strtolower((string)($headers['transfer-encoding']??'')),'chunked')) $body=urlp_decode_chunked($body,$limit);
    return ['status'=>$status,'headers'=>$headers,'body'=>$body];
}
function urlp_decode_chunked(string $data,int $limit): string {
    $out='';$pos=0;$len=strlen($data);while($pos<$len){$end=strpos($data,"\r\n",$pos);if($end===false)break;$line=trim(substr($data,$pos,$end-$pos));$size=hexdec(explode(';',$line,2)[0]);$pos=$end+2;if($size<=0)break;if($size>$limit-strlen($out)||$pos+$size>$len)throw new RuntimeException('Risposta HTTP chunked non valida o troppo grande.');$out.=substr($data,$pos,$size);$pos+=$size+2;}return $out;
}
function urlp_fetch(string $url,int $limit=5242880,bool $allowImage=false): array {
    $current=urlp_normalize_url($url);$redirects=0;
    while(true){$r=urlp_http_once($current,$limit);if(in_array($r['status'],[301,302,303,307,308],true)){$loc=(string)($r['headers']['location']??'');if($loc===''||$redirects++>=5)throw new RuntimeException('Reindirizzamento del sito non valido o eccessivo.');$current=urlp_resolve_url($current,$loc);if($current==='')throw new RuntimeException('Destinazione del reindirizzamento non valida.');continue;}
      if($r['status']<200||$r['status']>=300)throw new RuntimeException('Il sito ha risposto con codice HTTP '.$r['status'].'.');
      $type=strtolower(trim(explode(';',(string)($r['headers']['content-type']??''))[0]));if($allowImage){if($type!==''&&!str_starts_with($type,'image/'))throw new RuntimeException('La risorsa non è un’immagine.');}elseif($type!==''&&!in_array($type,['text/html','application/xhtml+xml'],true))throw new RuntimeException('Il collegamento non punta a una pagina HTML (tipo rilevato: '.$type.').');
      if($r['body']==='')throw new RuntimeException('La risorsa è vuota.');return ['url'=>$current,'html'=>$allowImage?$r['body']:urlp_to_utf8($r['body'],(string)($r['headers']['content-type']??'')),'headers'=>$r['headers']];
    }
}
function urlp_to_utf8(string $html,string $contentType): string {
    $charset='';if(preg_match('/charset\s*=\s*["\']?([^;"\'\s]+)/i',$contentType,$m))$charset=trim($m[1]);
    if($charset===''&&preg_match('/<meta[^>]+charset\s*=\s*["\']?([^"\'\s>]+)/i',$html,$m))$charset=trim($m[1]);
    if($charset!==''&&strcasecmp($charset,'utf-8')!==0&&function_exists('iconv')){$converted=@iconv($charset,'UTF-8//IGNORE',$html);if(is_string($converted))return $converted;}
    return $html;
}
function urlp_dom_inner(DOMNode $node): string { $out='';foreach($node->childNodes as $child)$out.=$node->ownerDocument->saveHTML($child);return $out; }
function urlp_extract(string $html,string $sourceUrl): array {
    $title='';$description='';$content='';$images=[];
    if(class_exists('DOMDocument')){
      $old=libxml_use_internal_errors(true);$dom=new DOMDocument('1.0','UTF-8');$dom->loadHTML('<?xml encoding="UTF-8">'.$html,LIBXML_NONET|LIBXML_NOWARNING|LIBXML_NOERROR);libxml_clear_errors();libxml_use_internal_errors($old);$xp=new DOMXPath($dom);
      $t=$xp->query('//title')->item(0);if($t)$title=trim($t->textContent);
      foreach($xp->query('//meta[translate(@name,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz")="description"]/@content') as $n){$description=trim($n->nodeValue);break;}
      foreach(['//script','//style','//noscript','//nav','//header','//footer','//aside','//form','//button','//input','//*[contains(translate(@class,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz"),"cookie")]','//*[contains(translate(@class,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz"),"advert")]','//*[contains(translate(@class,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz"),"social")]','//*[contains(translate(@id,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz"),"cookie")]'] as $query){$nodes=$xp->query($query);if($nodes)foreach(iterator_to_array($nodes) as $node)if($node->parentNode)$node->parentNode->removeChild($node);}
      $main=$xp->query('//article|//main|//*[@role="main"]')->item(0);if(!$main)$main=$xp->query('//body')->item(0);if(!$main)$main=$dom->documentElement;
      if($main){$content=urlp_dom_inner($main);foreach($xp->query('.//img[@src]', $main) as $img){$src=trim($img->getAttribute('src'));$abs=urlp_resolve_url($sourceUrl,$src);if($abs!=='')$images[]=['url'=>$abs,'alt'=>$img->getAttribute('alt')];}}
    } else {
      if(preg_match('~<title[^>]*>(.*?)</title>~is',$html,$m))$title=trim(html_entity_decode(strip_tags($m[1]),ENT_QUOTES|ENT_HTML5,'UTF-8'));
      if(preg_match('~<meta[^>]+name=["\']description["\'][^>]+content=["\']([^"\']*)["\']~i',$html,$m))$description=trim(html_entity_decode($m[1],ENT_QUOTES|ENT_HTML5,'UTF-8'));
      $body=$html;if(preg_match('~<(article|main)\b[^>]*>(.*?)</\1>~is',$html,$m))$body=$m[2];elseif(preg_match('~<body\b[^>]*>(.*?)</body>~is',$html,$m))$body=$m[1];
      $content=preg_replace('~<(script|style|noscript|nav|header|footer|aside|form)\b[^>]*>.*?</\1\s*>~is','',$body)??$body;
      if(preg_match_all('~<img\b[^>]*\bsrc\s*=\s*(["\'])(.*?)\1[^>]*>~is',$content,$mm,PREG_SET_ORDER))foreach($mm as $m){$abs=urlp_resolve_url($sourceUrl,$m[2]);if($abs!=='')$images[]=['url'=>$abs,'alt'=>''];}
    }
    $content=preg_replace('~<(script|style|iframe|object|embed|form|input|button|textarea|select|video|audio)\b[^>]*>.*?</\1\s*>~is','',$content)??$content;
    $content=preg_replace('~<(script|style|iframe|object|embed|form|input|button|textarea|select|video|audio)\b[^>]*/?>~is','',$content)??$content;
    $content=preg_replace('/\s+style\s*=\s*(?:"[^"]*"|\'[^\']*\')/i','',$content)??$content;
    // Rende assoluti i collegamenti e le immagini; elimina schemi pericolosi.
    $content=preg_replace_callback('~\b(href|src)\s*=\s*(["\'])(.*?)\2~is',function($m)use($sourceUrl){$v=trim(html_entity_decode($m[3],ENT_QUOTES|ENT_HTML5,'UTF-8'));if(strtolower($m[1])==='src'){$abs=urlp_resolve_url($sourceUrl,$v);return $abs!==''?$m[1].'="'.urlp_h($abs).'"':'';}if(preg_match('~^(?:javascript|data|vbscript):~i',$v))return '';if(preg_match('~^(?:https?://|mailto:|tel:|#)~i',$v))return $m[1].'="'.urlp_h($v).'"';$abs=urlp_resolve_url($sourceUrl,$v);return $abs!==''?$m[1].'="'.urlp_h($abs).'"':'';},$content)??$content;
    foreach($images as $im){$remote=urlp_h((string)$im['url']);$placeholder='uploads/images/urlp-pending-'.hash('sha256',(string)$im['url']).'.jpg';$content=str_replace('src="'.$remote.'"','src="'.$placeholder.'"',$content);}
    $content=sanitize_page_html($content);$plain=trim(preg_replace('/\s+/u',' ',html_entity_decode(strip_tags($content),ENT_QUOTES|ENT_HTML5,'UTF-8'))??'');
    if($title==='')$title=$plain!==''?(function_exists('mb_substr')?mb_substr($plain,0,90,'UTF-8'):substr($plain,0,90)):'Pagina importata';
    $title=function_exists('mb_substr')?mb_substr($title,0,220,'UTF-8'):substr($title,0,220);
    if($description==='')$description=function_exists('mb_substr')?mb_substr($plain,0,500,'UTF-8'):substr($plain,0,500);
    return ['title'=>$title,'description'=>function_exists('mb_substr')?mb_substr($description,0,500,'UTF-8'):substr($description,0,500),'content'=>$content,'images'=>$images,'plain'=>$plain];
}
function urlp_store_images(array $images,int $maxBytes): array {
    global $pdo;$dir=urlp_root().'/uploads/images';if(!is_dir($dir)&&!mkdir($dir,0755,true)&&!is_dir($dir))throw new RuntimeException('Cartella uploads/images non disponibile.');
    $map=[];$created=[];$count=0;
    foreach($images as $image){if($count>=12)break;$url=(string)($image['url']??'');if($url===''||isset($map[$url]))continue;try{$r=urlp_fetch($url,$maxBytes,true);}catch(Throwable $e){continue;}$data=$r['html'];$info=@getimagesizefromstring($data);if(!$info)continue;$mime=strtolower((string)($info['mime']??''));$exts=['image/jpeg'=>'jpg','image/png'=>'png','image/gif'=>'gif','image/webp'=>'webp'];if(!isset($exts[$mime])||strlen($data)>$maxBytes)continue;
      $stored=bin2hex(random_bytes(16)).'.'.$exts[$mime];$path=$dir.'/'.$stored;if(file_put_contents($path,$data,LOCK_EX)===false)continue;@chmod($path,0644);$created[]=$path;
      $name=basename((string)(parse_url($url,PHP_URL_PATH)??'immagine'));if($name==='')$name='immagine.'.$exts[$mime];$q=$pdo->prepare('INSERT INTO '.cms_table('media').' (original_name,stored_name,media_type,mime_type,file_size,created_at,deleted_at) VALUES (?,?,?,?,?,?,NULL)');$q->execute([$name,$stored,'image',$mime,strlen($data),date('Y-m-d H:i:s')]);
      $map[$url]='uploads/images/'.$stored;$count++;
    }
    return [$map,$created];
}
function urlp_preview_content(string $html): string { return preg_replace('~<img\b[^>]*src="uploads/images/urlp-pending-[a-f0-9]{64}\.jpg"[^>]*>~i','<p><em>[Immagine rilevata: verrà importata quando crei la pagina]</em></p>',$html)??$html; }
function urlp_prepare_content(array $data,int $maxImageBytes,array &$created): string {
    [$map,$created]=urlp_store_images($data['images'],$maxImageBytes);$html=(string)$data['content'];
    foreach($map as $remote=>$local){$placeholder='uploads/images/urlp-pending-'.hash('sha256',$remote).'.jpg';$html=str_replace($placeholder,urlp_h($local),$html);}
    $html=preg_replace('~<img\b(?=[^>]*src=(["\'])uploads/images/urlp-pending-[a-f0-9]{64}\.jpg\1)[^>]*>~i','',$html)??$html;
    return sanitize_page_html($html);
}
function urlp_history_by_hash(string $hash): ?array { global $pdo;$q=$pdo->prepare('SELECT * FROM '.urlp_table().' WHERE url_hash=? LIMIT 1');$q->execute([$hash]);$r=$q->fetch();return $r?:null; }
function urlp_imported_final(string $finalUrl,string $sourceHash): ?array { global $pdo;$q=$pdo->prepare('SELECT * FROM '.urlp_table().' WHERE final_url=? AND status=? AND url_hash<>? ORDER BY id DESC LIMIT 1');$q->execute([$finalUrl,'imported',$sourceHash]);$r=$q->fetch();return $r?:null; }
function urlp_create_page(array $cfg,string $sourceUrl,string $finalUrl,array $data): int {
    global $pdo;$category=(int)$cfg['category_id'];$q=$pdo->prepare('SELECT id FROM '.cms_table('categories').' WHERE id=? LIMIT 1');$q->execute([$category]);if(!$q->fetchColumn())throw new RuntimeException('Seleziona una categoria valida nelle impostazioni dell’estensione.');
    $normalized=urlp_normalize_url($sourceUrl);$hash=hash('sha256',$normalized);
    $created=[];$pdo->beginTransaction();
    try{$lock=$pdo->prepare('SELECT * FROM '.urlp_table().' WHERE url_hash=? FOR UPDATE');$lock->execute([$hash]);$old=$lock->fetch();if($old&&$old['status']==='imported')throw new RuntimeException('Questo indirizzo risulta già importato.');$content=urlp_prepare_content($data,(int)$cfg['max_image_bytes'],$created);$plain=trim(preg_replace('/\s+/u',' ',html_entity_decode(strip_tags($content),ENT_QUOTES|ENT_HTML5,'UTF-8'))??'');$excerptSource=trim((string)($data['description']??''))?:$plain;$excerpt=function_exists('mb_substr')?mb_substr($excerptSource,0,500,'UTF-8'):substr($excerptSource,0,500);
      $title=trim((string)$data['title']);if($title==='')$title='Pagina importata';$title=function_exists('mb_substr')?mb_substr($title,0,220,'UTF-8'):substr($title,0,220);$base=slugify($title);$slug=$base;$n=2;while(true){$s=$pdo->prepare('SELECT id FROM '.cms_table('pages').' WHERE slug=?');$s->execute([$slug]);if(!$s->fetch())break;$slug=$base.'-'.$n++;}
      $now=date('Y-m-d H:i:s');$status=$cfg['page_status']==='published'?'published':'draft';$ins=$pdo->prepare('INSERT INTO '.cms_table('pages').' (title,slug,content,excerpt,background_image,hide_title,hide_category,status,created_at,updated_at,published_at,deleted_at) VALUES (?,?,?,?,NULL,0,0,?,?,?,?,NULL)');$ins->execute([$title,$slug,$content,$excerpt,$status,$now,$now,$status==='published'?$now:null]);$pageId=(int)$pdo->lastInsertId();$pdo->prepare('INSERT INTO '.cms_table('page_categories').' (page_id,category_id) VALUES (?,?)')->execute([$pageId,$category]);
      if($old){$u=$pdo->prepare('UPDATE '.urlp_table().' SET final_url=?,title=?,page_id=?,status=?,note=NULL,imported_at=? WHERE id=?');$u->execute([$finalUrl,$title,$pageId,'imported',$now,$old['id']]);}
      else{$i=$pdo->prepare('INSERT INTO '.urlp_table().' (url_hash,source_url,final_url,title,page_id,status,note,fetched_at,imported_at) VALUES (?,?,?,?,?,"imported",NULL,?,?)');$i->execute([$hash,$normalized,$finalUrl,$title,$pageId,$now,$now]);}
      $pdo->commit();return $pageId;
    }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();foreach($created as $f)if(is_file($f))@unlink($f);throw $e;}
}
function urlp_admin_session_valid(): bool { global $pdo;if(empty($_SESSION['admin_id']))return false;$q=$pdo->prepare('SELECT is_active FROM '.cms_table('admins').' WHERE id=? LIMIT 1');$q->execute([(int)$_SESSION['admin_id']]);if((int)$q->fetchColumn()!==1){$_SESSION=[];if(session_status()===PHP_SESSION_ACTIVE)session_destroy();return false;}return true; }
function urlp_mobile_login(): ?string {
    global $pdo;if($_SERVER['REQUEST_METHOD']!=='POST'||($_POST['urlp_action']??'')!=='mobile_login')return null;csrf_check();$ipHash=hash('sha256',(string)($_SERVER['REMOTE_ADDR']??'unknown').'|url-to-page');$q=$pdo->prepare('SELECT COUNT(*) FROM '.cms_table('url_page_login_attempts').' WHERE ip_hash=? AND attempted_at>=?');$q->execute([$ipHash,date('Y-m-d H:i:s',time()-900)]);if((int)$q->fetchColumn()>=5)return 'Troppi tentativi. Riprova tra 15 minuti.';
    $u=trim((string)($_POST['username']??''));$q=$pdo->prepare('SELECT id,username,password_hash,role,display_name,is_active FROM '.cms_table('admins').' WHERE username=? LIMIT 1');$q->execute([$u]);$a=$q->fetch();if($a&&(int)$a['is_active']===1&&password_verify((string)($_POST['password']??''),(string)$a['password_hash'])){$pdo->prepare('DELETE FROM '.cms_table('url_page_login_attempts').' WHERE ip_hash=?')->execute([$ipHash]);session_regenerate_id(true);$_SESSION['admin_id']=(int)$a['id'];$_SESSION['admin_username']=$a['username'];$_SESSION['admin_role']=$a['role'];$_SESSION['admin_display_name']=$a['display_name']??'';$_SESSION['urlp_mobile_last_activity']=time();return null;}
    $pdo->prepare('INSERT INTO '.cms_table('url_page_login_attempts').' (ip_hash,attempted_at) VALUES (?,?)')->execute([$ipHash,date('Y-m-d H:i:s')]);return 'Credenziali amministrative non valide.';
}
function urlp_mobile_session_valid(): bool { if(!urlp_admin_session_valid())return false;$now=time();$last=(int)($_SESSION['urlp_mobile_last_activity']??0);if($last>0&&$now-$last>1800){unset($_SESSION['admin_id'],$_SESSION['admin_username'],$_SESSION['admin_role'],$_SESSION['admin_display_name'],$_SESSION['urlp_mobile_last_activity']);return false;}$_SESSION['urlp_mobile_last_activity']=$now;return true; }
function urlp_preview(string $url): array {
    $r=urlp_fetch($url);$data=urlp_extract($r['html'],$r['url']);return ['url'=>$r['url'],'data'=>$data];
}
