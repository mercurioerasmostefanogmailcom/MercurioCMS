<?php
require_once dirname(__DIR__,2).'/app/bootstrap.php';
require_admin();
require_once __DIR__.'/lib.php';
if(!urlp_is_active()){http_response_code(404);exit('Estensione non attiva.');}
urlp_ensure_schema();
if(!urlp_secure_transport()){http_response_code(403);exit('Per acquisire pagine web è necessaria una connessione HTTPS. In locale è consentito localhost.');}
$cfg=urlp_config();$errors=[];$notice='';$preview=$_SESSION['urlp_preview']??null;$mobileUrl=(string)($_SESSION['urlp_new_mobile_url']??'');unset($_SESSION['urlp_new_mobile_url']);
if($_SERVER['REQUEST_METHOD']==='POST'){
 csrf_check();$action=(string)($_POST['action']??'');
 if($action==='save_settings'){
  $cfg['category_id']=(int)($_POST['category_id']??0);$cfg['page_status']=(string)($_POST['page_status']??'draft');
  if(!in_array($cfg['page_status'],['draft','published'],true))$cfg['page_status']='draft';
  $q=$pdo->prepare('SELECT id FROM '.cms_table('categories').' WHERE id=?');$q->execute([$cfg['category_id']]);if(!$q->fetchColumn())$errors[]='Seleziona una categoria esistente.';else{urlp_save_config($cfg);$notice='Impostazioni salvate.';}
 }elseif($action==='generate_secret'){
  if(!urlp_secure_transport())$errors[]='Per generare il collegamento mobile è necessaria HTTPS.';else{$token=bin2hex(random_bytes(32));$cfg['secret_hash']=hash('sha256',$token);urlp_save_config($cfg);$_SESSION['urlp_new_mobile_url']=urlp_mobile_url($token);header('Location: admin.php?mobile=created');exit;}
 }elseif($action==='preview'){
  $input=(string)($_POST['source_url']??'');
  try{
   // Le impostazioni sono state salvate esplicitamente nel pannello precedente.
   $q=$pdo->prepare('SELECT id FROM '.cms_table('categories').' WHERE id=?');$q->execute([(int)$cfg['category_id']]);
   if(!$q->fetchColumn())throw new RuntimeException('Seleziona e salva una categoria valida nelle impostazioni prima di preparare l’anteprima.');
   $normalized=urlp_normalize_url($input);$hash=hash('sha256',$normalized);$old=urlp_history_by_hash($hash);
   if($old&&$old['status']==='imported')throw new RuntimeException('Questo indirizzo è già stato importato. Pagina associata: ID '.(int)$old['page_id'].'.');
   $result=urlp_preview($normalized);$sameFinal=urlp_imported_final($result['url'],$hash);
   if($sameFinal)throw new RuntimeException('Questo indirizzo reindirizza a una pagina già importata (pagina ID '.(int)$sameFinal['page_id'].').');
   // L'anteprima è soltanto temporanea: non crea pagine e non scrive nello storico.
   $_SESSION['urlp_preview']=['source'=>$normalized,'final'=>$result['url'],'data'=>$result['data'],'category_id'=>$cfg['category_id'],'page_status'=>$cfg['page_status'],'created'=>time()];
   $preview=$_SESSION['urlp_preview'];$notice='Anteprima pronta. Nessuna pagina è stata ancora creata.';
  }catch(Throwable $e){$errors[]=$e->getMessage();}
 }elseif($action==='create_page'){
  $preview=$_SESSION['urlp_preview']??null;
  if(!is_array($preview)||time()-(int)($preview['created']??0)>3600)$errors[]='L’anteprima è scaduta. Acquisisci nuovamente il collegamento.';
  else{try{
   $saveCfg=$cfg;$saveCfg['category_id']=(int)($preview['category_id']??$cfg['category_id']);$saveCfg['page_status']=(string)($preview['page_status']??$cfg['page_status']);
   $q=$pdo->prepare('SELECT id FROM '.cms_table('categories').' WHERE id=?');$q->execute([$saveCfg['category_id']]);if(!$q->fetchColumn())throw new RuntimeException('La categoria scelta non esiste più. Prepara nuovamente l’anteprima.');
   $title=trim((string)($_POST['title']??$preview['data']['title']));$preview['data']['title']=$title!==''?$title:$preview['data']['title'];
   $id=urlp_create_page($saveCfg,$preview['source'],$preview['final'],$preview['data']);unset($_SESSION['urlp_preview']);$preview=null;$notice='Pagina MercurioCMS creata correttamente (ID '.$id.').';
  }catch(Throwable $e){$errors[]=$e->getMessage();}}
 }elseif($action==='discard_preview'){unset($_SESSION['urlp_preview']);$preview=null;$notice='Anteprima eliminata.';}
}
if(isset($_GET['mobile'])&&$_GET['mobile']==='created')$notice='Collegamento mobile generato. Copialo ora: per sicurezza non verrà mostrato nuovamente.';
$categories=$pdo->query('SELECT id,name FROM '.cms_table('categories').' ORDER BY sort_order,name')->fetchAll();
$history=$pdo->query('SELECT id,source_url,final_url,title,page_id,status,note,fetched_at,imported_at FROM '.urlp_table().' WHERE status=\'imported\' ORDER BY id DESC LIMIT 100')->fetchAll();
$base=urlp_base_path();
?><!doctype html><html lang="it"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow,noarchive"><title>Importazione pagine da URL - MercurioCMS</title><link rel="stylesheet" href="<?=$base?>/assets/css/admin.css"><style>
.urlp-wrap{max-width:1180px;margin:0 auto;padding:28px 22px}.urlp-panel{background:#fff;border:1px solid #dce3ea;border-radius:12px;padding:20px;margin:16px 0}.urlp-panel h2{margin-top:0}.urlp-field{display:block;font-weight:600;margin:12px 0 6px}.urlp-wrap input[type=url],.urlp-wrap input[type=text],.urlp-wrap select{width:100%;max-width:760px;padding:11px;border:1px solid #cbd5df;border-radius:7px}.urlp-help{color:#687789;font-size:14px;line-height:1.5}.urlp-actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:14px}.urlp-preview{border:1px solid #e0e6eb;border-radius:9px;padding:16px;max-height:560px;overflow:auto}.urlp-preview img{max-width:100%;height:auto}.urlp-preview table{border-collapse:collapse;max-width:100%}.urlp-preview td,.urlp-preview th{border:1px solid #bbb;padding:5px}.urlp-ok{background:#edf8ef;border:1px solid #b9dfc1;padding:12px;border-radius:8px}.urlp-err{background:#fff0f0;border:1px solid #efbcbc;padding:12px;border-radius:8px}.urlp-url{max-width:360px;overflow-wrap:anywhere}.urlp-token{font-family:monospace;overflow-wrap:anywhere;background:#f2f5f7;padding:10px;border-radius:7px}
</style></head><body><?php
$adminActive='plugins';
$adminSidebarPath=dirname(__DIR__,2).'/admin/_sidebar.php';
$adminBasePath=rtrim($base,'/').'/admin/';
ob_start();
require $adminSidebarPath;
$adminSidebar=(string)ob_get_clean();
$adminSidebar=preg_replace_callback('/(\bhref\s*=\s*)([\"\'])(.*?)\2/i', function($m) use ($adminBasePath) {
    $href=html_entity_decode($m[3], ENT_QUOTES, 'UTF-8');
    if($href==='' || preg_match('~^(?:[a-z][a-z0-9+.-]*:|//|/|#|\?)~i',$href)) return $m[0];
    $parts=parse_url($href); $path=(string)($parts['path']??''); if($path==='') return $m[0];
    $segments=[];
    foreach(explode('/',rtrim($adminBasePath,'/').'/'.$path) as $segment){if($segment===''||$segment==='.')continue;if($segment==='..'){array_pop($segments);continue;}$segments[]=$segment;}
    $resolved='/'.implode('/',$segments);
    if(isset($parts['query']))$resolved.='?'.$parts['query'];
    if(isset($parts['fragment']))$resolved.='#'.$parts['fragment'];
    return $m[1].$m[2].htmlspecialchars($resolved,ENT_QUOTES,'UTF-8').$m[2];
},$adminSidebar)??$adminSidebar;
echo $adminSidebar;
?><main class="container urlp-wrap"><h1>Importazione pagine da URL</h1><p class="urlp-help">Acquisisci una pagina web e trasformala in una pagina MercurioCMS.</p>
<?php if($notice):?><p class="urlp-ok"><?=urlp_h($notice)?></p><?php endif;?><?php if($errors):?><div class="urlp-err"><ul><?php foreach($errors as $e):?><li><?=urlp_h($e)?></li><?php endforeach;?></ul></div><?php endif;?>
<?php if($mobileUrl):?><section class="urlp-panel"><h2>Collegamento riservato per smartphone</h2><p>Copialo sul telefono. Per accedere occorrono comunque le credenziali di un amministratore MercurioCMS. Il collegamento segreto non verrà mostrato di nuovo.</p><input class="urlp-token" type="text" id="urlp-mobile-url" readonly value="<?=urlp_h($mobileUrl)?>" aria-label="Collegamento smartphone"><div class="urlp-actions"><button type="button" id="urlp-copy-mobile">Copia collegamento</button><span id="urlp-copy-feedback" class="urlp-help" role="status" aria-live="polite"></span></div></section><?php endif;?>
<section class="urlp-panel"><h2>Impostazioni di importazione</h2><p class="urlp-help">Scegli e salva prima la categoria e lo stato che verranno assegnati alla pagina.</p>
<form method="post"><input type="hidden" name="csrf" value="<?=urlp_h(urlp_csrf())?>"><input type="hidden" name="action" value="save_settings">
<label class="urlp-field" for="urlp-category">Categoria della nuova pagina</label><select id="urlp-category" name="category_id" required><?php foreach($categories as $cat):?><option value="<?=(int)$cat['id']?>" <?=(int)$cfg['category_id']===(int)$cat['id']?'selected':''?>><?=urlp_h($cat['name'])?></option><?php endforeach;?></select>
<label class="urlp-field" for="urlp-status">Stato iniziale</label><select id="urlp-status" name="page_status"><option value="draft" <?=$cfg['page_status']==='draft'?'selected':''?>>Bozza</option><option value="published" <?=$cfg['page_status']==='published'?'selected':''?>>Pubblicata</option></select>
<div class="urlp-actions"><button type="submit">Salva impostazioni</button></div></form></section>
<section class="urlp-panel"><h2>Acquisisci una pagina web</h2><p class="urlp-help">Incolla l’indirizzo completo della pagina da cui vuoi ricavare il contenuto. L’estensione non effettua il login su siti riservati e non importa file PDF o altri documenti.</p><form method="post"><input type="hidden" name="csrf" value="<?=urlp_h(urlp_csrf())?>"><input type="hidden" name="action" value="preview"><label class="urlp-field" for="source_url">Indirizzo della pagina</label><input type="text" inputmode="url" id="source_url" name="source_url" required maxlength="2048" placeholder="https://www.esempio.it/articolo" value="<?=urlp_h((string)($preview['source']??''))?>"><div class="urlp-actions"><button type="submit">Leggi e prepara anteprima</button></div></form></section>
<?php if(is_array($preview)):?><section class="urlp-panel"><h2>Anteprima</h2><p><strong>Indirizzo acquisito:</strong> <a href="<?=urlp_h($preview['final'])?>" target="_blank" rel="noopener noreferrer"><?=urlp_h($preview['final'])?></a></p><form method="post"><input type="hidden" name="csrf" value="<?=urlp_h(urlp_csrf())?>"><input type="hidden" name="action" value="create_page"><label class="urlp-field">Titolo della pagina</label><input type="text" name="title" maxlength="220" required value="<?=urlp_h((string)$preview['data']['title'])?>"><p class="urlp-help">Categoria: <strong><?php $selectedCat='';foreach($categories as $cat){if((int)$cat['id']===(int)($preview['category_id']??$cfg['category_id'])){$selectedCat=$cat['name'];break;}}?><?=urlp_h($selectedCat)?></strong> · Stato iniziale: <strong><?=($preview['page_status']??$cfg['page_status'])==='published'?'pubblicata':'bozza'?></strong> · Immagini: <?=count($preview['data']['images'])?> rilevate (massimo 12 importate se accessibili).</p><div class="urlp-preview"><?=urlp_preview_content((string)$preview['data']['content'])?></div><div class="urlp-actions"><button type="submit">Salva la pagina in MercurioCMS</button></form><form method="post"><input type="hidden" name="csrf" value="<?=urlp_h(urlp_csrf())?>"><input type="hidden" name="action" value="discard_preview"><button type="submit" class="secondary">Annulla anteprima</button></form></div></section><?php endif;?>
<section class="urlp-panel"><h2>Accesso da smartphone</h2><p class="urlp-help">Genera un collegamento riservato da aprire sul telefono. Il collegamento non sostituisce l’autenticazione amministrativa.</p><form method="post" onsubmit="return confirm('Generare un nuovo collegamento? Quello precedente verrà invalidato.')"><input type="hidden" name="csrf" value="<?=urlp_h(urlp_csrf())?>"><input type="hidden" name="action" value="generate_secret"><button type="submit" class="secondary">Genera / rigenera collegamento mobile</button></form></section>
<section class="urlp-panel"><h2>Registro dei collegamenti importati</h2><p class="urlp-help">Sono mostrati gli ultimi 100 collegamenti salvati come pagine MercurioCMS. La sola anteprima non viene registrata; un indirizzo già importato non può essere importato una seconda volta.</p><?php if(!$history):?><p>Nessun collegamento ancora utilizzato.</p><?php else:?><div style="overflow-x:auto"><table><thead><tr><th>Data</th><th>Pagina / collegamento</th><th>Stato</th><th>Nota</th><th>Azione</th></tr></thead><tbody><?php foreach($history as $h):?><tr><td><?=urlp_h((string)$h['fetched_at'])?></td><td><strong><?=urlp_h((string)($h['title']?:$h['source_url']))?></strong><br><small class="urlp-url"><?=urlp_h((string)$h['source_url'])?></small></td><td><?=urlp_h((string)$h['status'])?></td><td><?=urlp_h((string)($h['note']??''))?></td><td><?php if($h['page_id']):?><a href="<?=urlp_h(urlp_admin_url('pages.php?edit='.(int)$h['page_id']))?>">Apri pagina (ID <?=(int)$h['page_id']?>)</a><?php else:?>—<?php endif;?></td></tr><?php endforeach;?></tbody></table></div><?php endif;?></section>
<p class="urlp-help">Importazione URL 1.0.3 · MercurioCMS 1.0.0</p></main></div></div>
<script>
(function(){
 const button=document.getElementById('urlp-copy-mobile');
 const field=document.getElementById('urlp-mobile-url');
 const feedback=document.getElementById('urlp-copy-feedback');
 if(!button||!field||!feedback)return;
 button.addEventListener('click',async function(){
  feedback.textContent='';
  let copied=false;
  try{
   if(navigator.clipboard&&typeof navigator.clipboard.writeText==='function'){
    await navigator.clipboard.writeText(field.value);copied=true;
   }
  }catch(e){copied=false;}
  if(!copied){
   try{field.focus();field.select();field.setSelectionRange(0,field.value.length);copied=!!document.execCommand('copy');}catch(e){copied=false;}
  }
  if(copied){feedback.textContent='Collegamento copiato negli appunti.';}
  else{field.focus();field.select();feedback.textContent='Copia automatica non disponibile: il collegamento è selezionato, premi CTRL+C (o Copia sul telefono).';}
 });
})();
</script></body></html>
