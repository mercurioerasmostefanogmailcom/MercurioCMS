<?php
/** Importazione pagine da URL per MercurioCMS 1.0.0. */
declare(strict_types=1);
require_once __DIR__ . '/lib.php';
if (function_exists('cms_register_admin_menu')) {
    cms_register_admin_menu('url-to-page', 'Importazione pagine da URL', '../plugins/url-to-page/admin.php');
}
